import fs from 'node:fs/promises';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const p=Presentation.create({slideSize:{width:1280,height:720}});
const s=p.slides.add();s.background.fill='#FFFFFF';
const a=s.shapes.add({geometry:'roundRect',position:{left:90,top:100,width:300,height:90},fill:'#EAF3F8',line:{fill:'#28536B',width:2}});
a.text='日本語の表示確認\n担当と実施タイミング';a.text.style={typeface:'Meiryo',fontSize:24,color:'#18334B',alignment:'center',verticalAlignment:'middle',insets:{left:8,right:8,top:6,bottom:6}};
const b=s.shapes.add({geometry:'diamond',position:{left:540,top:100,width:190,height:100},fill:'#FFF2CC',line:{fill:'#99732C',width:2}});
b.text='復旧済みか';b.text.style={typeface:'Meiryo',fontSize:22,alignment:'center',verticalAlignment:'middle'};
s.shapes.connect(a,b,{kind:'straight',fromSide:'right',toSide:'left',line:{fill:'#28536B',width:2},head:{type:'triangle',width:'sm',length:'sm'}}).bringToFront();
const t=s.tables.add({rows:3,columns:2,left:80,top:290,width:1100,height:280,columnWidths:[250,850],values:[['確認項目','記入例'],['一次対応','SKY365は合意した範囲と手順で対応する。'],['期間','翌営業日から5営業日目まで。']]});
t.borders.assign({fill:'#CAD6DF',width:1,style:'solid'});
for(let r=0;r<3;r++)for(let c=0;c<2;c++){let cell=t.getCell(r,c);cell.fill=r===0?'#18334B':'#F4F7FA';cell.text.style={typeface:'Meiryo',fontSize:24,color:r===0?'#FFFFFF':'#18334B',bold:r===0};}
await (await PresentationFile.exportPptx(p)).save('D:/projects/itil/.build-explanation/probe.pptx');
const png=await p.export({slide:s,format:'png',scale:1});await fs.writeFile('D:/projects/itil/.build-explanation/probe.png',new Uint8Array(await png.arrayBuffer()));
console.log('probe ok');
