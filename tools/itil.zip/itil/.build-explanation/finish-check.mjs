import fs from 'node:fs/promises';
import {chromium} from 'playwright';
import {FileBlob,PresentationFile} from '@oai/artifact-tool';
const root='D:/projects/itil',b=root+'/.build-explanation';
const p=await PresentationFile.importPptx(await FileBlob.load(root+'/output/ITサービス運用ルール_説明資料.pptx'));
const changes=[];
for(let i=0;i<p.slides.items.length;i++){const data=new Uint8Array(await(await p.export({slide:p.slides.items[i],format:'png',scale:1})).arrayBuffer());const name=String(i+1).padStart(2,'0');const old=await fs.readFile(b+'/final-previews/'+name+'.png');if(!old.equals(Buffer.from(data)))changes.push(i+1);await fs.writeFile(b+'/final-previews/'+name+'.png',data);}
console.log('Final slide render changes',changes);
const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}});
await page.goto('file:///D:/projects/itil/output/ITサービス運用ルール_説明資料.html');
const result=await page.evaluate(()=>({sections:document.querySelectorAll('section').length,flows:document.querySelectorAll('.flow').length,overflow:[...document.querySelectorAll('.activity')].filter(e=>e.scrollHeight>e.clientHeight+2).map(e=>e.textContent),scripts:document.scripts.length,svg:document.querySelectorAll('svg').length,checks:[...document.querySelectorAll('.content-table tbody th')].filter(e=>/^A[1-6]-[1-4]$/.test(e.textContent)).length}));
await page.locator('#problem-flow').screenshot({path:b+'/html-problem-final.png'});
await fs.writeFile(b+'/final-content-check.json',JSON.stringify({pptxSlideCount:p.slides.items.length,changedSlides:changes,html:result},null,2));console.log(result);await browser.close();
