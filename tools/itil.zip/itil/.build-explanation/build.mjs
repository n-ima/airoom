import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
import {pages,graphs,sources,checks,examples,sourceFiles} from './content.mjs';
const ROOT='D:/projects/itil',BUILD=ROOT+'/.build-explanation',OUT=ROOT+'/output';
const SKILL='C:/Users/nimao/.codex/plugins/cache/openai-primary-runtime/presentations/26.909.11814/skills/presentations';
const PY='C:/Users/nimao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const C={ink:'#19384A',blue:'#275D78',teal:'#007F83',light:'#EAF3F8',line:'#B9CBD5',amber:'#FFF0C2',paper:'#F5F8FA'};
process.env.RUNTIME_NODE_MODULES='C:/Users/nimao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const htmlText=s=>esc(s).replaceAll('\n','<br>');
// The last action belongs to the problem owner, not the leader.
graphs.problem.rows=5;graphs.problem.phases=[[0,1,'調査開始時'],[1,2,'調査期限まで'],[2,3,'対策期限まで'],[3,5,'効果確認・\n完了時']];
Object.assign(graphs.problem.nodes.find(n=>n.id==='end'),{c:0,r:4,text:'問題課題を完了'});
graphs.problem.edges=graphs.problem.edges.filter(e=>!(e.from==='valid'));
graphs.problem.nodes.push({id:'again',c:2,r:3,text:'原因分析へ戻る\n次の調査・期限を決定',kind:'action'});
graphs.problem.edges.push({from:'valid',to:'end',label:'はい',labelAt:[530,393]},{from:'valid',to:'again',label:'不十分',labelAt:[812,320]});
graphs.problem.phases[1][2]='調査\n期限まで';graphs.problem.phases[2][2]='対策\n期限まで';
graphs.problem.nodes.find(n=>n.id==='reg').text='問題登録\n障害課題と関連付け';
graphs.problem.nodes.find(n=>n.id==='review').text='原因と対策の\nつながりを確認';
graphs.problem.nodes.find(n=>n.id==='action').text='対策・共有\n本番変更は判定会議へ';
graphs.problem.edges.push({from:'again',to:'analysis',out:'right',in:'left',via:[[1140,341],[1140,465],[151,465],[151,169]]});
graphs.incidentUser.nodes.find(n=>n.id==='answer').text='回答を受け取る\n受付終了';
graphs.incidentUser.nodes.find(n=>n.id==='record').text='Backlogへ登録\n既存課題があれば関連付け';
graphs.incidentUser.nodes.find(n=>n.id==='record').text='Backlogへ登録\n既存課題には関連付け';
graphs.incidentAuto.edges.find(e=>e.from==='scope'&&e.to==='check').via=[[301.6666667,416.25]];
graphs.incidentRecovery.edges.find(e=>e.from==='normal'&&e.to==='recover').via=[[157,308.75],[157,201.25]];
graphs.incidentUser.phases[0][2]='問い\n合わせ時';
graphs.incidentUser.edges.find(e=>e.to==='answer').label='回答';
graphs.incidentUser.edges.find(e=>e.to==='answer').labelAt=[463,235];
graphs.releaseBefore.phases[0][2]='会議の\n前営業日\nまで';
graphs.releaseAfter.phases[1][2]='初期\nフォロー\n期間中';
Object.assign(graphs.releaseAfter.edges.find(e=>e.to==='normal'),{out:'bottom',in:'top',via:[[988.333,363],[645,363]],labelAt:[804,355]});
Object.assign(graphs.releaseAfter.edges.find(e=>e.to==='extend'),{out:'right',in:'right',via:[[1133,308.75],[1133,416.25]],labelAt:[1130,354]});
Object.assign(graphs.releaseAfter.edges.find(e=>e.from==='extend'),{out:'bottom',in:'left',via:[[988.333,454],[150,454],[150,201.25]]});
graphs.overview.nodes.find(n=>n.id==='release').text='リリース管理\n判定・反映・フォロー';
Object.assign(graphs.overview.edges.find(e=>e.from==='release'&&e.to==='incident'),{start:[510,156],end:[870,305],via:[[510,230],[870,230]],labelAt:[665,212]});
pages.find(p=>p.id==='problem-scope').rows[3][0]='確認メンバー・\nリーダー';
pages.find(p=>p.id==='sheet-writing').rows[0][1]='確認済／未完了／対象外。未調査は未完了。既存設定で足りると確認できた場合も確認済。';
graphs.example.phases[2][2]='10/20〜26\n初期\nフォロー';
graphs.example.nodes.find(n=>n.id==='deploy').text='Bの開始前確認後に反映\n15:00〜15:20';
graphs.example.nodes.find(n=>n.id==='check').text='反映結果を確認';
pages.find(p=>p.id==='post-record').rows[1][1]='手順に沿って作業。主要動作・データを確認。';
pages.find(p=>p.id==='post-record').rows[3][2]='連絡結果、異常・残件、関連する障害課題。';
pages.find(p=>p.id==='start').rows[3][0]='本番へ変更を\n入れるとき';
pages.find(p=>p.id==='start').rows[4][1]='迷った箇所や記入しづらかった項目を既存会議で確認し、手順・対象一覧へ反映。';
pages.find(p=>p.id==='example-period').lead='業務の必要時刻は平日11:00（架空の合意）。9:00の確認と復旧で間に合う前提。翌営業日から5営業日を数える。';
function model(g){
 const cw=(1160-130)/(g.lanes?.length||3),rh=(470-40)/(g.rows||4);
 const nodes=g.nodes.map(n=>g.free?{...n}:{...n,w:n.kind==='decision'?150:250,h:g.rows===5?54:62,x:130+(n.c+.5)*cw-(n.kind==='decision'?150:250)/2,y:40+(n.r+.5)*rh-(g.rows===5?54:62)/2});
 const by=Object.fromEntries(nodes.map(n=>[n.id,n]));
 const port=(n,side)=>side==='left'?[n.x,n.y+n.h/2]:side==='right'?[n.x+n.w,n.y+n.h/2]:side==='top'?[n.x+n.w/2,n.y]:[n.x+n.w/2,n.y+n.h];
 const edges=g.edges.map(e=>{const a=by[e.from],b=by[e.to];let out=e.out,into=e.in;
  if(!out){if(Math.abs(a.y-b.y)<5){out=a.x<b.x?'right':'left';into=a.x<b.x?'left':'right';}else{out=a.y<b.y?'bottom':'top';into=a.y<b.y?'top':'bottom';}}
  const p=e.start||port(a,out),q=e.end||port(b,into),pts=[p];
  if(e.via)pts.push(...e.via);else if(Math.abs(p[0]-q[0])>.5&&Math.abs(p[1]-q[1])>.5){const y=(p[1]+q[1])/2;pts.push([p[0],y],[q[0],y]);}
  pts.push(q);for(let i=1;i<pts.length;i++){if(Math.abs(pts[i][0]-pts[i-1][0])>.1&&Math.abs(pts[i][1]-pts[i-1][1])>.1){pts.splice(i,0,[pts[i][0],pts[i-1][1]]);i++;}}let labelAt=e.labelAt;if(!labelAt){let max=-1;for(let i=1;i<pts.length;i++){const d=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);if(d>max){max=d;labelAt=[(pts[i][0]+pts[i-1][0])/2,(pts[i][1]+pts[i-1][1])/2-15];}}}
  return {...e,pts,labelAt};});
 return {...g,nodes,edges,cw,rh};
}
const pres=Presentation.create({slideSize:{width:1280,height:720}});
function shape(s,x,y,w,h,fill,line=C.line,geom='rect'){return s.shapes.add({geometry:geom,position:{left:x,top:y,width:w,height:h},fill,line:{fill:line,width:1}});}
function text(s,txt,x,y,w,h,size=24,bold=false,color=C.ink,align='left'){
 const z=shape(s,x,y,w,h,'#FFFFFF00','#FFFFFF00');z.text=txt;
 z.text.style={typeface:'Meiryo',fontSize:size,bold,color,alignment:align,verticalAlignment:'middle',insets:{left:0,right:0,top:0,bottom:0}};return z;
}
function table(s,headers,rows,widths,size=22,y=178,h=440){
 const values=[headers,...rows],t=s.tables.add({rows:values.length,columns:headers.length,left:60,top:y,width:1160,height:h,columnWidths:widths,values});
 t.borders.assign({fill:C.line,width:1,style:'solid'});t.rows[0].height=44;
 for(let r=1;r<values.length;r++)t.rows[r].height=(h-44)/rows.length;
 for(let r=0;r<values.length;r++)for(let c=0;c<headers.length;c++){
  const v=t.getCell(r,c);v.fill=r===0?C.ink:(r%2?C.paper:'#FFFFFF');
  v.text.style={typeface:'Meiryo',fontSize:r===0?21:size,color:r===0?'#FFFFFF':C.ink,bold:r===0||c===0};
  t.cells.block({row:r,column:c,rowCount:1,columnCount:1}).assign({margins:{left:12,right:12,top:10,bottom:8},anchor:'center'});
 }return t;
}
function drawGraph(s,g){
 const m=model(g),ox=60,oy=170;
 if(!g.free){
  const vals=Array.from({length:g.rows+1},(_,r)=>r===0?['実施時点',...g.lanes]:Array(g.lanes.length+1).fill(''));
  const t=s.tables.add({rows:g.rows+1,columns:g.lanes.length+1,left:ox,top:oy,width:1160,height:470,columnWidths:[130,...g.lanes.map(()=>m.cw)],values:vals});
  t.rows[0].height=40;for(let r=1;r<=g.rows;r++)t.rows[r].height=m.rh;
  t.borders.assign({fill:C.line,width:1,style:'solid'});
  for(let r=0;r<=g.rows;r++)for(let c=0;c<=g.lanes.length;c++){const cell=t.getCell(r,c);cell.fill=r===0?C.ink:c===0?'#E7EEF2':'#FFFFFF';cell.text.style={typeface:'Meiryo',fontSize:19,bold:true,color:r===0?'#FFFFFF':C.ink,alignment:'center',verticalAlignment:'middle'};}
  for(const [a,b,label]of g.phases){if(b-a>1)t.merge({startRow:a+1,endRow:b,startColumn:0,endColumn:0});t.getCell(a+1,0).value=label;}
 }
 for(const e of m.edges){
  for(let i=1;i<e.pts.length;i++){let [x1,y1]=e.pts[i-1],[x2,y2]=e.pts[i];if(Math.hypot(x1-x2,y1-y2)<.5)continue;
   const a=shape(s,ox+x1-.01,oy+y1-.01,.02,.02,'#FFFFFF00','#FFFFFF00'),b=shape(s,ox+x2-.01,oy+y2-.01,.02,.02,'#FFFFFF00','#FFFFFF00');
   s.shapes.connect(a,b,{kind:'straight',line:{fill:C.blue,width:2},...(i===e.pts.length-1?{tail:{type:'triangle',width:'sm',length:'sm'}}:{})}).bringToFront();
  }
 }
 for(const n of m.nodes){shape(s,ox+n.x,oy+n.y,n.w,n.h,n.kind==='decision'?C.amber:C.light,C.blue,n.kind==='decision'?'diamond':'roundRect');text(s,n.text,ox+n.x+6,oy+n.y+2,n.w-12,n.h-4,n.kind==='decision'?20:20,false,C.ink,'center');}
 for(const e of m.edges)if(e.label){const w=Math.max(52,e.label.length*17+12),[x,y]=e.labelAt;shape(s,ox+x-w/2,oy+y-12,w,24,'#FFFFFF','#FFFFFF00');text(s,e.label,ox+x-w/2,oy+y-12,w,24,16,false,C.blue,'center');}
}
function graphHTML(g){const m=model(g);let a='';
 if(!g.free){a+='<table class="lane-grid"><colgroup><col style="width:130px">'+g.lanes.map(()=>`<col style="width:${m.cw}px">`).join('')+'</colgroup><thead><tr><th>実施時点</th>'+g.lanes.map(l=>'<th>'+esc(l)+'</th>').join('')+'</tr></thead><tbody>';
  for(let r=0;r<g.rows;r++){a+=`<tr style="height:${m.rh}px">`;let phase=g.phases.find(p=>p[0]===r);if(phase)a+=`<th rowspan="${phase[1]-phase[0]}">${htmlText(phase[2])}</th>`;a+=g.lanes.map(()=>'<td></td>').join('')+'</tr>'; }a+='</tbody></table>';
 }
 for(const e of m.edges)for(let i=1;i<e.pts.length;i++){const[x,y]=e.pts[i-1],[x2,y2]=e.pts[i],length=Math.hypot(x2-x,y2-y),angle=Math.atan2(y2-y,x2-x)*180/Math.PI;if(length<.5)continue;a+=`<span aria-hidden="true" class="edge${i===e.pts.length-1?' arrow':''}" style="left:${x}px;top:${y}px;width:${length}px;transform:rotate(${angle}deg)"></span>`;}
 for(const n of m.nodes)a+=`<div class="activity ${n.kind}" style="left:${n.x}px;top:${n.y}px;width:${n.w}px;height:${n.h}px"><span>${htmlText(n.text)}</span></div>`;
 for(const e of m.edges)if(e.label)a+=`<span class="edge-label" style="left:${e.labelAt[0]}px;top:${e.labelAt[1]}px">${esc(e.label)}</span>`;
 return `<div class="flow-scroll"><figure class="flow" aria-label="列は担当、行は実施時点。矢印が作業順序、ひし形が判断を示す。">${a}</figure></div>`;
}
const tableHTML=p=>`<div class="table-scroll"><table class="content-table"><colgroup>${p.widths.map(w=>`<col style="width:${w/11.6}%">`).join('')}</colgroup><thead><tr>${p.headers.map(h=>'<th>'+esc(h)+'</th>').join('')}</tr></thead><tbody>${p.rows.map(r=>'<tr>'+r.map((c,i)=>`<${i?'td':'th'}>${htmlText(c)}</${i?'td':'th'}>`).join('')+'</tr>').join('')}</tbody></table></div>`;
let sections=[];const tableOwners=[];
for(let index=0;index<pages.length;index++){
 const p=pages[index],s=pres.slides.add();s.background.fill='#FFFFFF';
 text(s,p.chapter,60,17,1100,24,16,true,C.teal);
 text(s,p.title,60,48,1160,55,36,true);
 text(s,p.lead,60,105,1160,54,22);
 shape(s,60,159,1160,3,C.teal,C.teal);
 let body='';
 if(p.type==='diagram'){drawGraph(s,graphs[p.graph]);body=graphHTML(graphs[p.graph]);if(!graphs[p.graph].free)tableOwners.push(index+1);}
 if(p.type==='table'){table(s,p.headers,p.rows,p.widths,p.font||22);body=tableHTML(p);tableOwners.push(index+1);}
 if(p.type==='intro'){
  table(s,['プロセス','目的'],p.items,[340,820],26,200,305);tableOwners.push(index+1);
  text(s,'読み方：全体像 → 障害対応 → 原因分析 → リリース判定 → 実施後確認',65,548,1150,50,24,true,C.teal);
  body=tableHTML({headers:['プロセス','目的'],rows:p.items,widths:[340,820]})+'<p class="reading">全体像 → 障害対応 → 原因分析 → リリース判定 → 実施後確認</p>';
 }
 if(p.type==='blocks'){body='<div class="columns">';p.columns.forEach((col,i)=>{let x=60+i*600;text(s,col.title,x,184,550,45,27,true,C.teal);shape(s,x,237,550,2,C.line,C.line);col.lines.forEach((ln,j)=>{text(s,'・'+ln,x,250+j*60,550,56,22);});body+='<div><h3>'+esc(col.title)+'</h3><ul>'+col.lines.map(l=>'<li>'+esc(l)+'</li>').join('')+'</ul></div>';});body+='</div>';}
 if(p.type==='references'){
  p.items.forEach(([title,url],i)=>{text(s,title,60,178+i*58,1160,25,22,true);text(s,url,60,206+i*58,1160,20,14,false,C.blue);});
  body='<ul class="sources">'+p.items.map(([t,u])=>`<li><a href="${esc(u)}">${esc(t)}</a><small>${esc(u)}</small></li>`).join('')+'</ul><h3>元のMarkdown文書</h3><p>'+sourceFiles.map(esc).join('／')+'</p>';
 }
 text(s,p.note,60,651,1160,39,17,false,C.ink);
 text(s,`${String(index+1).padStart(2,'0')} / ${pages.length}`,1100,696,120,17,12,false,C.blue,'right');
 s.speakerNotes.textFrame.setText(`出典：既存のITサービス運用ルールと関連Markdown8文書。\n${p.note}\n${(p.refs||[]).map(k=>sources[k].join('\n')).join('\n')}\n全参考資料は最終ページ参照。`);
 sections.push(`<section id="${p.id}"><div class="section-meta">${esc(p.chapter)} <span>${index+1} / ${pages.length}</span></div><h2>${esc(p.title)}</h2><p class="lead">${esc(p.lead)}</p>${body}<p class="note">${esc(p.note)}</p></section>`);
}
const css=`:root{--ink:${C.ink};--line:${C.line};--teal:${C.teal};--blue:${C.blue}}*{box-sizing:border-box}body{margin:0;color:var(--ink);background:#edf2f5;font-family:Meiryo,'Yu Gothic',sans-serif;font-size:17px;line-height:1.8}header{background:var(--ink);color:white;padding:42px max(28px,calc((100% - 1160px)/2))}h1{margin:0;font-size:34px}header p{margin:8px 0 0;color:#dbe9ef}.container{max-width:1280px;margin:auto;padding:24px}nav{background:#fff;padding:24px 30px;border-left:6px solid var(--teal);margin-bottom:24px}nav h2{margin:0 0 12px;font-size:23px}nav ul{columns:2;list-style:none;padding:0;margin:0}nav li{break-inside:avoid;padding:3px 0;font-size:15px}a{color:#075c7d;text-underline-offset:3px}section{background:white;padding:30px 20px;margin:0 0 24px;scroll-margin-top:16px;border:1px solid #dbe4e9}.section-meta{font-size:14px;font-weight:bold;color:var(--teal)}.section-meta span{float:right;color:#647988}h2{font-size:29px;line-height:1.5;margin:8px 0 10px}h3{font-size:21px;color:var(--teal)}.lead{font-size:19px;margin:0 0 24px;padding-bottom:18px;border-bottom:3px solid var(--teal)}.note{background:#f0f5f7;padding:12px 16px;margin:22px 0 0;border-left:4px solid var(--teal);font-size:16px}.reading{font-size:20px;color:var(--teal);font-weight:bold}.table-scroll,.flow-scroll{overflow-x:auto}.content-table{border-collapse:collapse;width:100%;min-width:750px;table-layout:fixed}.content-table th,.content-table td{border:1px solid var(--line);padding:15px 16px;vertical-align:top;text-align:left;overflow-wrap:anywhere}.content-table thead{background:var(--ink);color:white}.content-table tbody tr:nth-child(odd){background:#f5f8fa}.content-table tbody th{font-weight:bold}.columns{display:grid;grid-template-columns:1fr 1fr;gap:44px}.columns li{margin:12px 0}.flow{position:relative;width:1160px;height:470px;margin:0 auto;font-size:20px;line-height:1.45}.lane-grid{position:absolute;inset:0;border-collapse:collapse;table-layout:fixed;width:1160px;height:470px}.lane-grid th,.lane-grid td{border:1px solid var(--line);text-align:center;padding:0}.lane-grid thead{height:40px;background:var(--ink);color:white;font-size:19px}.lane-grid tbody th{background:#e7eef2;font-size:19px}.activity{line-height:1.2;position:absolute;display:flex;align-items:center;justify-content:center;text-align:center;padding:2px 6px;border:1px solid var(--blue);border-radius:8px;background:#eaf3f8;z-index:2}.activity.decision{background:none;border:0;border-radius:0}.activity.decision:before{content:'';position:absolute;inset:0;background:#fff0c2;clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);z-index:-1}.edge{position:absolute;height:2px;background:var(--blue);transform-origin:left center;z-index:1}.arrow:after{content:'';position:absolute;right:-1px;top:-4px;border-left:9px solid var(--blue);border-top:5px solid transparent;border-bottom:5px solid transparent}.edge-label{position:absolute;transform:translate(-50%,-50%);z-index:3;background:white;padding:0 5px;font-size:16px;color:var(--blue);white-space:nowrap}.sources li{margin-bottom:14px}.sources small{display:block;overflow-wrap:anywhere;font-size:13px;color:#536c7b}footer{padding:15px 0 30px;text-align:center;font-size:14px}@media(max-width:800px){.container{padding:12px}header{padding:24px}h1{font-size:28px}h2{font-size:25px}nav ul{columns:1}.columns{grid-template-columns:1fr}section{padding:20px 14px}.lead{font-size:17px}}@media print{body{background:white;font-size:11pt}.container{max-width:none;padding:0}header,nav,footer{display:none}section{break-before:page;border:0;margin:0;padding:0}.flow-scroll{overflow:visible;zoom:.82}.content-table{min-width:0}.note{break-inside:avoid}@page{size:A4 landscape;margin:14mm}}`;
await fs.mkdir(OUT,{recursive:true});await fs.mkdir(BUILD+'/previews',{recursive:true});
await fs.writeFile(OUT+'/ITサービス運用ルール_説明資料.html',`<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ITサービス運用ルール｜説明資料</title><style>${css}</style></head><body><header><h1>ITサービス運用ルール</h1><p>インシデント管理・問題管理・リリース判定　｜　説明資料・運用案　2026年10月5日</p></header><main class="container"><nav aria-label="目次"><h2>目次</h2><ul>${pages.map((p,i)=>`<li><a href="#${p.id}">${String(i+1).padStart(2,'0')}　${esc(p.title)}</a></li>`).join('')}</ul></nav>${sections.join('\n')}</main><footer>図の列＝担当、行＝実施時点。矢印＝作業順序、ひし形＝判断。／ 記入例はすべて架空。</footer></body></html>`,'utf8');
await (await PresentationFile.exportPptx(pres)).save(BUILD+'/candidate.pptx');
console.log('Built',pages.length,'pages; checks',checks.length,'examples',examples.length);
for(let i=0;i<pages.length;i++){const blob=await pres.export({slide:pres.slides.items[i],format:'png',scale:1});await fs.writeFile(BUILD+`/previews/${String(i+1).padStart(2,'0')}.png`,new Uint8Array(await blob.arrayBuffer()));console.log('Rendered',i+1);}
const {finalizePresentation}=await import(pathToFileURL(SKILL+'/container_tools/artifact_tool_utils.mjs').href);
const finalName=process.env.ITIL_FINAL_NAME||'ITサービス運用ルール_説明資料.pptx';
const result=await finalizePresentation({workspaceDir:ROOT,candidatePath:BUILD+'/candidate.pptx',finalPath:OUT+'/'+finalName,pythonExecutable:PY,integrityValidatorPath:SKILL+'/container_tools/inspect_presentation_package_integrity.py',layoutValidatorPath:SKILL+'/container_tools/inspect_presentation_layout_geometry.py',layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',...tableOwners.flatMap(n=>['--require-native-table-slide',String(n)])],requiredNativeTableOwnerSlides:tableOwners,fontPolicy:{basis:'design',families:['Meiryo']},verifyArtifactToolImport:true,receiptPath:BUILD+'/'+finalName+'.validation.json'});
console.log(JSON.stringify(result));
