# ITサービス運用ルール

更新日：2026年10月5日／版：0.9（運用案）

10人の同じチームで開発と運用を行うための共通ルール。日常運用は全員で分担し、変更内容や対応手順は開発した担当者からチーム全体へ共有する。

## 1. 各プロセスの目的

| プロセス | 目的 |
|---|---|
| インシデント管理 | サービスをできるだけ早く復旧し、業務・利用者への影響を最小限に抑える |
| 問題管理 | 障害の原因を調べ、再発や影響を減らす |
| リリース管理・リリース判定 | 変更を業務で利用できる状態にするため、準備を確認して実施を判断する |

## 2. プロセス間の流れ

主なリリースの入口は案件。障害の復旧はインシデント管理、必要な原因分析・再発防止は問題管理で扱う。

```mermaid
flowchart LR
    A[案件] --> R[リリース管理]
    R --> O[通常運用]
    O -->|障害発生| I[インシデント管理]
    I -->|復旧| O
    I -->|原因分析・再発防止が必要| P[問題管理]
    P -->|本番変更が必要| R
    R -->|リリースに伴う障害| I
```

- 原因が未解明でも、復旧と必要な調査の引継ぎができればインシデントは完了可能。
- 問題対策に本番変更があればリリース判定を通す。手順・工程だけの改善は問題管理内で進め、いずれも効果を確認する。
- 案件・リリース・インシデント・問題の記録は、Backlogで関連づける。

全体はプロセス間のつながりを示す。各プロセスの文書では、列を担当、行をタイミングとしたアクティビティ図で具体的な進め方を示す。

## 3. 共通の担当・対応時間

- **担当者：** 課題ごとに1人を決定。開発に関係する調査・修正は、その開発担当を基本とする。
- **リーダー：** 2人のうち1人を判断者とし、不在時はもう1人が代行。
- **対応時間：** 原則は平日日中。朝までに対応が必要な処理だけ、対応時間・担当・連絡先を個別に合意。

「全員で運用する」場合も、個々の課題の担当を曖昧にしない。Backlogは担当・進捗・結果を把握するための手段である。

## 4. 使用する文書

| 用途 | 文書 |
|---|---|
| 障害の受付・通知・復旧、SKY365との分担 | [インシデント管理](インシデント管理.md) |
| 原因分析・再発防止 | [問題管理](問題管理.md) |
| リリース判定、チーム共有、初期フォローの期間 | [リリース管理・リリース判定](リリース管理・リリース判定.md) |
| 判定会議への提出・承認記録 | [リリース判定・承認シート](リリースチェックシート.md)／[記入例](記入例_リリース判定.md) |
| 実施結果・初期フォローの終了確認 | [リリース後の確認記録](リリース後確認記録.md)／[記入例](記入例_リリース後確認.md) |

## 参考サイト

各資料の考え方を参考に、チーム向けに簡略化した運用案。担当・期間・様式はITILが一律に定めたものではない。

- [PeopleCert：Incident Management](https://www.peoplecert.org/browse-certifications/it-governance-and-service-management/ITIL-1/itil4-practices-incident-management-3684) — サービスの迅速な復旧。
- [PeopleCert：Problem Management](https://www.peoplecert.org/browse-certifications/it-governance-and-service-management/ITIL-1/itil4-practices-problem-management-3688) — 原因分析・回避策・再発防止。
- [PeopleCert：Release Management](https://www.peoplecert.org/browse-certifications/it-governance-and-service-management/ITIL-1/itil-4-practitioner-release-management-3798) — 変更を利用可能にするための準備。
- [Google SRE：Monitoring Distributed Systems](https://sre.google/sre-book/monitoring-distributed-systems/) — 行動につながる監視・通知。
- [Google SRE：The Evolving SRE Engagement Model](https://sre.google/sre-book/evolving-sre-engagement-model/) — 運用準備・知識共有・支援。
- [Google SRE：Postmortem Culture](https://sre.google/workbook/postmortem-culture/) — 根拠のある分析と改善。
