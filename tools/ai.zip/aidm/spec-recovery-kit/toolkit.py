"""Evidence collection and verification for specification recovery. Python 3.11+.

No third-party dependencies. Does not call an LLM or modify source systems.
See GUIDE.md for human/AI stages and collection limitations.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import posixpath
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def write_rows(path, values):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("".join(json.dumps(v, ensure_ascii=False) + "\n" for v in values), encoding="utf-8")


def fresh(path):
    path = Path(path).resolve()
    if path.exists():
        raise ValueError("Output already exists; use a new run directory: " + str(path))
    path.mkdir(parents=True)
    return path


def finish(out, metadata):
    files = []
    for p in sorted(Path(out).rglob("*")):
        if p.is_file() and p.name != "manifest.json":
            files.append({"path": p.relative_to(out).as_posix(), "bytes": p.stat().st_size,
                          "sha256": digest(p.read_bytes())})
    dump(Path(out) / "manifest.json", {"captured_at": now(), **metadata, "files": files})


def get(url, headers, raw=False):
    """GET only; redact error bodies; bounded retry for throttling and transient failures."""
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=60) as response:
                data = response.read()
            return data if raw else json.loads(data)
        except urllib.error.HTTPError as exc:
            if exc.code not in (429, 500, 502, 503, 504) or attempt == 3:
                raise RuntimeError(f"HTTP {exc.code} from {urllib.parse.urlsplit(url).hostname}; response body omitted") from None
            delay = exc.headers.get("Retry-After", "")
            time.sleep(min(float(delay) if delay.isdigit() else 2 ** attempt, 30))
        except (urllib.error.URLError, TimeoutError):
            if attempt == 3:
                raise RuntimeError("Network request failed; verify network and credentials") from None
            time.sleep(2 ** attempt)


def query(base, params):
    return base + "?" + urllib.parse.urlencode(params, doseq=True)


def token(name):
    value = os.environ.get(name)
    if not value:
        raise ValueError(f"Set {name} through your approved secret mechanism; do not paste it into prompts")
    return value


def local_name(tag):
    return tag.rsplit("}", 1)[-1]


def xml_text(element):
    return "".join(n.text or "" for n in element.iter() if local_name(n.tag) == "t")


def relationships(z, part):
    directory, filename = posixpath.split(part)
    relpath = posixpath.join(directory, "_rels", filename + ".rels")
    if relpath not in z.namelist():
        return {}
    result = {}
    for rel in ET.fromstring(z.read(relpath)):
        target = rel.attrib.get("Target", "")
        result[rel.attrib["Id"]] = {**rel.attrib, "resolved": posixpath.normpath(
            target.lstrip("/") if target.startswith("/") else posixpath.join(directory, target))}
    return result


def extract_xlsx(source, output):
    source = Path(source).resolve()
    if source.suffix.lower() not in (".xlsx", ".xlsm"):
        raise ValueError("Only OOXML .xlsx/.xlsm; export legacy .xls separately, preserve original")
    out = fresh(output)
    shutil.copy2(source, out / ("original" + source.suffix.lower()))
    warnings = ["Not a renderer. Supply visual captures separately; drawing XML is retained, not semantically interpreted.",
                "Formula cached values may be stale; shared formula followers are not expanded.",
                "External links, macros and embedded objects are not executed."]
    with zipfile.ZipFile(source) as z:
        names = z.namelist()
        if sum(i.file_size for i in z.infolist()) > 512 * 1024 * 1024:
            raise ValueError("Uncompressed workbook exceeds 512 MiB; split or inspect separately")
        shared = []
        if "xl/sharedStrings.xml" in names:
            shared = [xml_text(n) for n in ET.fromstring(z.read("xl/sharedStrings.xml"))]
        workbook = ET.fromstring(z.read("xl/workbook.xml"))
        rels = relationships(z, "xl/workbook.xml")
        sheets = []
        for sheet in workbook.iter():
            if local_name(sheet.tag) != "sheet":
                continue
            rid = next((v for k, v in sheet.attrib.items() if local_name(k) == "id"), None)
            part = rels[rid]["resolved"]
            root = ET.fromstring(z.read(part))
            cells, merges, dimensions, links = [], [], [], []
            for node in root.iter():
                kind = local_name(node.tag)
                if kind == "c":
                    v = next((n.text for n in node if local_name(n.tag) == "v"), None)
                    t = node.attrib.get("t", "n")
                    value = shared[int(v)] if t == "s" and v is not None else xml_text(node) if t == "inlineStr" else v
                    f = next((n for n in node if local_name(n.tag) == "f"), None)
                    cells.append({"address": node.attrib.get("r"), "type": t, "raw_value": value,
                                  "style_index": node.attrib.get("s"),
                                  "formula": f.text if f is not None else None,
                                  "formula_attributes": f.attrib if f is not None else {}})
                elif kind == "mergeCell":
                    merges.append(node.attrib["ref"])
                elif kind in ("row", "col", "sheetFormatPr", "sheetView", "pageSetup", "pageMargins"):
                    dimensions.append({"type": kind, **node.attrib})
                elif kind == "hyperlink":
                    links.append(node.attrib)
            sheets.append({"name": sheet.attrib["name"], "sheet_id": sheet.attrib["sheetId"],
                           "state": sheet.attrib.get("state", "visible"), "part": part,
                           "cells": cells, "merges": merges, "layout": dimensions,
                           "hyperlinks": links, "relationships": relationships(z, part)})
        # Retain all package members under verified paths. No extraction of traversal paths.
        for name in names:
            target = (out / "package" / name).resolve()
            if not target.is_relative_to(out / "package"):
                raise ValueError("Invalid OOXML member path")
            if not name.endswith("/"):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(name))
        comments = []
        for name in names:
            if name.endswith(".xml") and ("comment" in name.lower() or "person" in name.lower()):
                root = ET.fromstring(z.read(name))
                for node in root.iter():
                    if local_name(node.tag) in ("comment", "threadedComment"):
                        comments.append({"part": name, "attributes": node.attrib,
                                         "text": "".join(node.itertext())})
        dump(out / "workbook.json", {"sheets": sheets, "comments": comments,
                                     "defined_names": [{"attributes": n.attrib, "text": n.text}
                                                       for n in workbook.iter() if local_name(n.tag) == "definedName"]})
    finish(out, {"kind": "xlsx", "source": str(source), "status": "structured_only", "warnings": warnings})


def figma_index(document, comments):
    nodes = []
    def walk(node, ancestors):
        nodes.append({k: node[k] for k in ("id", "name", "type", "characters", "absoluteBoundingBox", "visible",
                     "componentId", "componentProperties", "annotations", "interactions", "transitionNodeID") if k in node}
                     | {"ancestors": ancestors})
        for child in node.get("children", []):
            walk(child, ancestors + [node["id"]])
    walk(document["document"], [])
    byid = {n["id"]: n for n in nodes}
    comment_map = {c["id"]: c for c in comments.get("comments", [])}
    threads = {}
    for c in comment_map.values():
        parent, seen = c, set()
        while parent.get("parent_id") in comment_map and parent["parent_id"] not in seen:
            seen.add(parent["id"])
            parent = comment_map[parent["parent_id"]]
        rootid = parent.get("parent_id") or parent["id"]
        group = threads.setdefault(rootid, {"root_id": rootid, "comments": [], "binding": "unresolved", "candidate_nodes": []})
        group["comments"].append(c)
    for rootid, group in threads.items():
        group["comments"].sort(key=lambda c: c.get("created_at", ""))
        root = comment_map.get(rootid)
        if not root:
            group["binding"] = "missing_parent"
            continue
        meta = root.get("client_meta") or {}
        if meta.get("node_id") in byid:
            group.update(binding="explicit_frame_not_confirmed_control", candidate_nodes=[meta["node_id"]])
        elif meta.get("node_id"):
            group["binding"] = "missing_anchor_node"
        elif all(k in meta for k in ("x", "y")) and not any(k in meta for k in ("region_width", "region_height")):
            for n in nodes:
                b = n.get("absoluteBoundingBox", {})
                if all(k in b for k in ("x", "y", "width", "height")) and b["x"] <= meta["x"] <= b["x"] + b["width"] and b["y"] <= meta["y"] <= b["y"] + b["height"]:
                    group["candidate_nodes"].append(n["id"])
            group["binding"] = "coordinate_candidates_only"
        elif "region_width" in meta:
            group["binding"] = "region_requires_visual_review"
    return {"nodes": nodes, "threads": list(threads.values()),
            "warning": "Anchor means location, not approved target or decision. Resolved does not mean approved."}


def collect_figma(key, output, ids=None, version=None):
    out = fresh(output)
    headers = {"X-Figma-Token": token("FIGMA_TOKEN")}
    base = "https://api.figma.com/v1"
    key = urllib.parse.quote(key, safe="")
    start = now()
    doc = get(query(f"{base}/files/{key}", {"version": version} if version else {}), headers)
    dump(out / "file.json", doc)
    comments = get(f"{base}/files/{key}/comments", headers)
    dump(out / "comments.json", comments)
    dump(out / "index.json", figma_index(doc, comments))
    warnings = ["Comments are the retrieval-time snapshot, not a historical version snapshot.",
                "Node tree, comments and renders are separate requests; compare versions/timestamps."]
    if ids:
        params = {"ids": ids, "format": "png", "scale": 2, "version": doc["version"]}
        images = get(query(f"{base}/images/{key}", params), headers)
        dump(out / "image-urls.json", images)
        warnings.append("Image URLs expire. Export/store the actual frame and surrounding canvas captures before review.")
    else:
        warnings.append("No image IDs requested. Visual export is still required.")
    finish(out, {"kind": "figma", "source": key, "version": doc.get("version"), "started_at": start,
                 "status": "structured_only", "warnings": warnings})


def collect_sheets(key, output):
    out = fresh(output)
    headers = {"Authorization": "Bearer " + token("GOOGLE_ACCESS_TOKEN")}
    key = urllib.parse.quote(key, safe="")
    drive = "https://www.googleapis.com/drive/v3/files/" + key
    metadata_url = query(drive, {"fields": "id,name,mimeType,version,modifiedTime", "supportsAllDrives": "true"})
    before = get(metadata_url, headers)
    dump(out / "metadata-before.json", before)
    sheet = get(query("https://sheets.googleapis.com/v4/spreadsheets/" + key, {"includeGridData": "true"}), headers)
    dump(out / "spreadsheet.json", sheet)
    comments, page, warnings = [], None, []
    while True:
        params = {"fields": "*", "pageSize": 100, "includeDeleted": "true"}
        if page:
            params["pageToken"] = page
        result = get(query(drive + "/comments", params), headers)
        comments.extend(result.get("comments", []))
        page = result.get("nextPageToken")
        if not page:
            break
    # Fetch replies explicitly and paginate; do not rely on embedded replies being complete.
    for c in comments:
        replies, page = [], None
        while True:
            params = {"fields": "*", "pageSize": 100, "includeDeleted": "true"}
            if page:
                params["pageToken"] = page
            result = get(query(drive + "/comments/" + urllib.parse.quote(c["id"], safe="") + "/replies", params), headers)
            replies.extend(result.get("replies", []))
            page = result.get("nextPageToken")
            if not page:
                break
        c["replies"] = replies
    dump(out / "comments.json", {"comments": comments})
    after = get(metadata_url, headers)
    dump(out / "metadata-after.json", after)
    changed = any(before.get(k) != after.get(k) for k in ("version", "modifiedTime"))
    warnings.extend(["Export sheet images/PDF and inspect drawings separately; JSON is not visual completeness.",
                     "Native comment anchors may be absent/opaque. Do not infer exact cell binding from nearby text.",
                     "Deleted comment text may be unavailable; empty comment results are not proof that no discussion existed."])
    if changed:
        warnings.append("File changed during capture. Re-capture in a stable window before baselining.")
    finish(out, {"kind": "google_sheets", "source": key,
                 "status": "changed_during_capture" if changed else "structured_only", "warnings": warnings})


def inventory(root, output):
    root = Path(root).resolve()
    output = Path(output).resolve()
    if output.is_relative_to(root):
        raise ValueError("Inventory output must be outside the source root to avoid self-inclusion")
    out = fresh(output)
    skipped_dirs = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".aws"}
    records, exclusions = [], []
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in list(dirs):
            p = Path(directory) / name
            if name in skipped_dirs or p.is_symlink():
                exclusions.append({"path": p.relative_to(root).as_posix(), "reason": "default excluded directory or symlink; review scope"})
                dirs.remove(name)
        for name in sorted(files):
            p = Path(directory) / name
            relative = p.relative_to(root).as_posix()
            if p.is_symlink() or name == ".env" or name.startswith(".env.") or p.suffix.lower() in (".pem", ".key", ".pfx"):
                exclusions.append({"path": relative, "reason": "potential secret or symlink; obtain sanitized config separately"})
                continue
            data = p.read_bytes()
            records.append({"path": relative, "bytes": len(data), "sha256": digest(data)})
    write_rows(out / "files.jsonl", records)
    dump(out / "exclusions.json", exclusions)
    finish(out, {"kind": "source_inventory", "source": str(root), "status": "inventory_only",
                 "warnings": ["No call graph or business rules inferred. Verify deployment commit, flags and DB definitions separately."]})


def init_run(output):
    out = fresh(output)
    for name in ("evidence", "claims", "decisions", "tests", "coverage", "discrepancies"):
        write_rows(out / f"{name}.jsonl", [])
    dump(out / "scope.json", {"feature_id": "REPLACE", "baseline": "REPLACE", "owner": "REPLACE",
                              "in_scope": [], "out_of_scope": [], "unresolved": []})


def add_evidence(run, file, eid, kind, locator, excerpt, snapshot):
    path = Path(run) / "evidence.jsonl"
    existing = rows(path)
    if any(e["id"] == eid for e in existing):
        raise ValueError("Evidence id already exists")
    file = Path(file).resolve(strict=True)
    record = {"id": eid, "kind": kind, "source": str(file), "locator": locator,
              "excerpt": excerpt, "snapshot": snapshot, "sha256": digest(file.read_bytes())}
    write_rows(path, existing + [record])


def verify_manifest(directory):
    directory = Path(directory).resolve()
    manifest = read(directory / "manifest.json")
    errors = []
    for item in manifest["files"]:
        p = (directory / item["path"]).resolve()
        if not p.is_relative_to(directory) or not p.is_file():
            errors.append("Missing or invalid: " + item["path"])
        elif digest(p.read_bytes()) != item["sha256"]:
            errors.append("Hash mismatch: " + item["path"])
    return {"ok": not errors, "errors": errors, "meaning": "Checks listed snapshot files only, not collection completeness."}


def validate(run, gate=False):
    run = Path(run)
    tables = {n: rows(run / f"{n}.jsonl") for n in ("evidence", "claims", "decisions", "tests", "coverage", "discrepancies")}
    errors = []
    indexes = {}
    def need(ok, msg):
        if not ok:
            errors.append(msg)
    for name, items in tables.items():
        index = {}
        for item in items:
            key = item.get("id")
            need(isinstance(key, str) and bool(key), name + ": missing id")
            need(key not in index, name + ": duplicate id " + str(key))
            index[key] = item
        indexes[name] = index
    ev = indexes["evidence"]
    for e in tables["evidence"]:
        for key in ("kind", "source", "locator", "snapshot", "excerpt", "sha256"):
            need(bool(e.get(key)), f"{e.get('id')}: missing {key}")
        need(bool(re.fullmatch(r"[0-9a-f]{64}", e.get("sha256", ""))), f"{e.get('id')}: invalid sha256")
        source = e.get("source", "")
        if source and not source.startswith(("https://", "http://")):
            p = Path(source)
            if not p.is_absolute():
                p = run / p
            need(p.is_file(), f"{e.get('id')}: missing local evidence file")
            if p.is_file():
                need(digest(p.read_bytes()) == e.get("sha256"), f"{e.get('id')}: evidence hash mismatch")
    for c in tables["claims"]:
        key = c["id"]
        need(c.get("status") in ("candidate", "confirmed", "retired", "blocked"), key + ": invalid status")
        need(c.get("origin") in ("document", "implementation", "observation", "decision"), key + ": invalid origin")
        for field in ("feature_id", "statement", "precondition", "outcome", "rationale_status"):
            need(bool(c.get(field)), key + ": missing " + field)
        need(bool(c.get("evidence_ids")), key + ": no evidence")
        for eid in c.get("evidence_ids", []):
            need(eid in ev, key + ": unknown evidence " + eid)
        need(c.get("rationale_status") in ("documented", "hypothesis", "unknown"), key + ": invalid rationale status")
        if c.get("status") == "confirmed":
            ds = [d for d in tables["decisions"] if d.get("id") == c.get("decision_id") and key in d.get("claim_ids", [])]
            need(bool(ds), key + ": confirmed requires linked decision")
            for d in ds:
                need(all(d.get(f) for f in ("decided_by", "decided_at", "reason", "selected_behavior", "authority_basis")), key + ": incomplete decision")
    for d in tables["decisions"]:
        need(bool(d.get("claim_ids")), d["id"] + ": no claims")
        for cid in d.get("claim_ids", []):
            need(cid in indexes["claims"], d["id"] + ": unknown claim " + cid)
        for eid in d.get("evidence_ids", []):
            need(eid in ev, d["id"] + ": unknown decision evidence " + eid)
    for t in tables["tests"]:
        need(bool(t.get("claim_ids")), t["id"] + ": no claims")
        need(isinstance(t.get("input"), dict), t["id"] + ": input must be object")
        need(isinstance(t.get("expected"), dict) and bool(t.get("expected")), t["id"] + ": expected must be nonempty object")
        need(bool(t.get("oracle_basis")), t["id"] + ": no expected-result basis")
        need(t.get("status") in ("draft", "approved"), t["id"] + ": invalid test status")
        if t.get("status") == "approved":
            need(bool(t.get("approved_by")), t["id"] + ": approved_by missing")
        for cid in t.get("claim_ids", []):
            need(cid in indexes["claims"], t["id"] + ": unknown claim " + cid)
            if t.get("status") == "approved":
                need(indexes["claims"].get(cid, {}).get("status") == "confirmed", t["id"] + ": oracle references unconfirmed claim")
    for c in tables["coverage"]:
        need(c.get("evidence_id") in ev, c["id"] + ": unknown evidence")
        need(c.get("disposition") in ("mapped", "excluded", "unresolved"), c["id"] + ": invalid disposition")
        if c.get("disposition") == "mapped":
            need(bool(c.get("claim_ids")), c["id"] + ": mapped without claims")
            for cid in c.get("claim_ids", []):
                need(cid in indexes["claims"], c["id"] + ": unknown claim " + cid)
        else:
            need(bool(c.get("reason")), c["id"] + ": disposition reason required")
    for d in tables["discrepancies"]:
        need(d.get("status") in ("open", "resolved", "accepted_difference"), d["id"] + ": invalid status")
        for cid in d.get("claim_ids", []):
            need(cid in indexes["claims"], d["id"] + ": unknown claim " + cid)
        if d.get("status") != "open":
            need(d.get("decision_id") in indexes["decisions"], d["id"] + ": resolution requires decision")
    if gate:
        scope = read(run / "scope.json")
        for field in ("feature_id", "baseline", "owner"):
            need(bool(scope.get(field)) and scope[field] != "REPLACE", "scope: missing " + field)
        need(bool(scope.get("in_scope")), "scope: in_scope empty")
        need(not scope.get("unresolved"), "scope: unresolved items")
        for table in ("evidence", "claims", "tests", "coverage", "decisions"):
            need(bool(tables[table]), table + ": empty cannot pass readiness")
        for c in tables["claims"]:
            need(c.get("status") in ("confirmed", "retired"), c["id"] + ": unresolved claim")
            if c.get("status") == "confirmed":
                need(any(c["id"] in t.get("claim_ids", []) and t.get("status") == "approved" for t in tables["tests"]), c["id"] + ": no approved test")
        for eid in ev:
            need(any(c.get("evidence_id") == eid and c.get("disposition") != "unresolved" for c in tables["coverage"]), eid + ": evidence not dispositioned")
        for c in tables["coverage"]:
            need(c.get("disposition") != "unresolved", c["id"] + ": unresolved coverage")
        for d in tables["discrepancies"]:
            need(d.get("status") != "open", d["id"] + ": unresolved discrepancy")
    return {"ok": not errors, "errors": errors, "gate": gate,
            "meaning": "Structural checks only; does not prove extraction completeness, evidence truth, authority or business correctness."}


def compare(expected, actual, prefix="$"):
    """Subset on objects, exact equality on lists/scalars; strict bool/number distinction."""
    errors = []
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return [prefix + ": expected object"]
        for key, value in expected.items():
            if key not in actual:
                errors.append(prefix + "." + key + ": missing")
            else:
                errors.extend(compare(value, actual[key], prefix + "." + key))
    elif type(expected) is not type(actual) or expected != actual:
        errors.append(prefix + ": expected " + repr(expected) + ", actual " + repr(actual))
    return errors


def run_tests(tests_path, adapter, output, timeout=30):
    cases = rows(tests_path)
    if not cases:
        raise ValueError("No tests; cannot report success")
    out = fresh(output)
    adapter = Path(adapter).resolve(strict=True)
    results = []
    for case in cases:
        result = {"id": case.get("id"), "claim_ids": case.get("claim_ids", []), "started_at": now()}
        if case.get("status") != "approved" or not case.get("approved_by") or not case.get("oracle_basis") or not case.get("claim_ids") or not isinstance(case.get("expected"), dict) or not case["expected"]:
            result.update(status="blocked", detail="Approved nonempty oracle required")
        else:
            try:
                # Only input is passed to the adapter; never send the expected result.
                process = subprocess.run([sys.executable, str(adapter)],
                    input=json.dumps({"id": case["id"], "input": case["input"]}, ensure_ascii=False),
                    text=True, encoding="utf-8", capture_output=True, timeout=timeout,
                    env={**os.environ, "PYTHONIOENCODING": "utf-8"}, check=False)
                if process.returncode:
                    result.update(status="blocked", detail="Adapter exited " + str(process.returncode))
                else:
                    observed = json.loads(process.stdout)
                    diffs = compare(case["expected"], observed)
                    result.update(status="failed" if diffs else "passed", differences=diffs, observed=observed)
            except (subprocess.TimeoutExpired, json.JSONDecodeError, KeyError, OSError) as exc:
                result.update(status="blocked", detail=type(exc).__name__)
        results.append(result)
    dump(out / "results.json", {"tests_sha256": digest(Path(tests_path).read_bytes()),
                               "adapter_sha256": digest(adapter.read_bytes()), "results": results})
    finish(out, {"kind": "test_run", "adapter": str(adapter),
                 "status": "passed" if all(r["status"] == "passed" for r in results) else "not_passed"})
    return results


def review(run, output):
    run = Path(run)
    sections = []
    for name in ("evidence", "claims", "discrepancies", "decisions", "coverage", "tests"):
        cards = "".join("<article><h3>" + html.escape(str(v.get("id", ""))) + "</h3><pre>" +
                        html.escape(json.dumps(v, ensure_ascii=False, indent=2)) + "</pre></article>" for v in rows(run / f"{name}.jsonl"))
        sections.append("<section><h2>" + name + "</h2>" + cards + "</section>")
    output = Path(output)
    if output.exists():
        raise ValueError("Review output already exists; use a new file")
    output.write_text("<!doctype html><html lang='ja'><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
        "<title>仕様復元レビュー</title><style>body{font:16px/1.7 system-ui;max-width:1100px;margin:40px auto;padding:0 20px;background:#f5f7fa;color:#182433}"
        "article{background:white;border:1px solid #d4dce5;padding:18px;margin:12px 0;border-radius:8px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px}h1,h2{color:#153b57}</style>"
        "<h1>仕様復元レビュー</h1><p>記録の閲覧用です。承認操作や原資料画像の自動取得は行いません。原資料と並べて確認してください。</p>" +
        "".join(sections) + "</html>", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("xlsx", "inventory"):
        p = sub.add_parser(name); p.add_argument("source"); p.add_argument("output")
    p = sub.add_parser("figma"); p.add_argument("key"); p.add_argument("output"); p.add_argument("--ids"); p.add_argument("--version")
    p = sub.add_parser("sheets"); p.add_argument("key"); p.add_argument("output")
    p = sub.add_parser("init"); p.add_argument("output")
    p = sub.add_parser("verify-manifest"); p.add_argument("directory")
    p = sub.add_parser("evidence"); p.add_argument("run"); p.add_argument("file"); p.add_argument("--id", required=True); p.add_argument("--kind", required=True); p.add_argument("--locator", required=True); p.add_argument("--excerpt", required=True); p.add_argument("--snapshot", required=True)
    p = sub.add_parser("validate"); p.add_argument("run"); p.add_argument("--gate", action="store_true")
    p = sub.add_parser("review"); p.add_argument("run"); p.add_argument("output")
    p = sub.add_parser("test"); p.add_argument("tests"); p.add_argument("adapter"); p.add_argument("output"); p.add_argument("--timeout", type=int, default=30)
    a = parser.parse_args()
    if a.command == "xlsx": extract_xlsx(a.source, a.output)
    elif a.command == "inventory": inventory(a.source, a.output)
    elif a.command == "figma": collect_figma(a.key, a.output, a.ids, a.version)
    elif a.command == "sheets": collect_sheets(a.key, a.output)
    elif a.command == "init": init_run(a.output)
    elif a.command == "evidence": add_evidence(a.run, a.file, a.id, a.kind, a.locator, a.excerpt, a.snapshot)
    elif a.command == "verify-manifest":
        result = verify_manifest(a.directory)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1
    elif a.command == "review": review(a.run, a.output)
    elif a.command == "validate":
        result = validate(a.run, a.gate)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1
    elif a.command == "test":
        results = run_tests(a.tests, a.adapter, a.output, a.timeout)
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0 if all(r["status"] == "passed" for r in results) else 2 if any(r["status"] == "blocked" for r in results) else 1
    print("Completed: " + a.command)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, RuntimeError, OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        sys.exit(2)
