# 業務設計書復元の実行キット

Excel、Google Sheets、Figmaのコメント、既存実装から、AI開発の基準となる業務設計書と受入テストを作るための手順書・プロンプト・補助コードです。

最初に[GUIDE.md](GUIDE.md)を読み、工程に沿って[PROMPTS.md](PROMPTS.md)を使います。台帳の形式は[DATA-CONTRACT.md](DATA-CONTRACT.md)、完了判定は[CHECKLIST.md](CHECKLIST.md)、出典は[SOURCES.md](SOURCES.md)です。

## このキットが実行すること

- OOXML形式のExcelから元データ・セル・結合・コメント等を取得し、図形や書式の元部品も保持。
- Figmaのノードとコメントを取得し、スレッド化と対象候補の索引を作成。
- Google Sheetsの構造、Driveコメントと返信、取得前後の版情報を取得。
- ソースのファイル一覧・ハッシュと除外一覧を作成。
- 根拠・仕様候補・判断・テストの参照と準備状況を機械検査。
- 期待値をアダプターに渡さず、実際の観測結果と比較。

資料の意味解釈と設計書の生成は、工程別プロンプトを使って利用者のAI環境で行います。LLMへの自動送信や全工程の自律実行は組み込んでいません。実行アダプターは対象システムに合わせてP11で作成します。これは全システムでそのまま動く業務テスト実装ではありません。

## すぐに動作を確かめる

Python 3.11以降があれば追加パッケージは不要です。この端末では次の実行ファイルを確認しています。

```powershell
Set-Location 'D:\projects\aidm\spec-recovery-kit'
$specPython = 'C:\Users\nimao\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $specPython -m unittest discover -s tests -v
& $specPython scripts/create_demo.py work/my-demo-001
& $specPython toolkit.py validate work/my-demo-001 --gate
& $specPython toolkit.py test work/my-demo-001/tests.jsonl examples/adapter_legacy_bug.py work/my-demo-001-legacy
& $specPython toolkit.py test work/my-demo-001/tests.jsonl examples/adapter_correct.py work/my-demo-001-correct
& $specPython toolkit.py review work/my-demo-001 work/my-demo-001-review.html
```

不具合デモでは100000円ちょうどのケースだけが失敗します。正常デモは3件が合格します。既存出力先は上書きしないため、二回目は名前を変えてください。別端末では$specPythonをインストール済みPythonの絶対パスに変更するか、pythonコマンドを使います。

## 認証情報を渡す

Figmaではfile_content:readとfile_comments:readを持ち、対象ファイルへアクセス可能なPersonal access tokenを用意します。Googleでは組織のOAuth設定に従い、SheetsとDriveの読み取りができるaccess tokenを用意します。例えばspreadsheets.readonlyとdrive.readonly相当の範囲が必要です。スコープは組織の許可・API仕様に合わせ、既存コネクターの利用でも構いません。

端末の履歴にトークンを直接書かない入力例です。実際のトークンはこの文書やプロンプトへ保存しません。

```powershell
$specSecret = Read-Host 'Figma token' -AsSecureString
$env:FIGMA_TOKEN = [System.Net.NetworkCredential]::new('', $specSecret).Password
& $specPython toolkit.py figma FILE_KEY captures/figma-001 --ids '12:34'
Remove-Item Env:FIGMA_TOKEN

$specSecret = Read-Host 'Google OAuth access token' -AsSecureString
$env:GOOGLE_ACCESS_TOKEN = [System.Net.NetworkCredential]::new('', $specSecret).Password
& $specPython toolkit.py sheets SPREADSHEET_ID captures/sheets-001
Remove-Item Env:GOOGLE_ACCESS_TOKEN
```

FILE_KEY、SPREADSHEET_ID、ノードIDは実在する値へ置き換えます。スコープが不足した403を空のコメント一覧と解釈しません。コードはトークンの発行・更新を行いません。

## 検証済みと未検証

作成時にPython 3.12.14でオフラインテスト25件が合格しています。合成データによる境界不具合の検出と正常例の成功も確認します。検証ログはdelivery-validation.txtに保存しています。

Google/Figmaの実接続、実物ExcelのPDF出力、利用者資料での抽出精度、対象システムのテスト接続は未実施です。キットの実行成功を業務仕様の正しさと混同しないよう、GUIDEとCHECKLISTに確認手順を記載しています。

## コマンド一覧

```text
python toolkit.py init OUTPUT
python toolkit.py xlsx WORKBOOK OUTPUT
python toolkit.py figma FILE_KEY OUTPUT [--ids IDS] [--version VERSION]
python toolkit.py sheets SPREADSHEET_ID OUTPUT
python toolkit.py inventory SOURCE_ROOT OUTPUT_OUTSIDE_SOURCE
python toolkit.py evidence RUN FILE --id ID --kind KIND --locator LOCATION --excerpt TEXT --snapshot VERSION
python toolkit.py verify-manifest CAPTURE_DIRECTORY
python toolkit.py validate RUN [--gate]
python toolkit.py review RUN OUTPUT.html
python toolkit.py test TESTS.jsonl ADAPTER.py OUTPUT [--timeout SECONDS]
```

収集とデモ作成は新しいディレクトリに出力します。initは台帳のみを初期化します。レビューHTMLは読み取り用です。実装の実行はtestで指定したアダプターだけが行います。
