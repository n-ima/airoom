# 公式資料と公開事例

確認日：2026年10月5日。APIと製品機能は更新されるため、接続時に権限・対応形式・制限を再確認してください。本キットの全体手順、プロンプト、完了基準、コードは本件への提案・実装です。下記はその一部の取得方法や考え方の根拠です。

| 出典 | 確認した内容 | この資料だけでは言えないこと |
|---|---|---|
| [Figma File endpoints](https://developers.figma.com/docs/rest-api/file-endpoints/) | ノードJSON、版、画像出力、対応するannotations | フレーム画像だけで周辺注記まで完全取得できること |
| [Figma Comments endpoints](https://developers.figma.com/docs/rest-api/comments-endpoints/) | ファイル単位のコメント取得とread scope | 過去のファイル版に対応したコメントの完全な復元 |
| [Figma Comments types](https://developers.figma.com/docs/rest-api/comments-types/) | 親コメント、作成時刻、解決時刻、位置情報 | 解決済みが業務上の承認済みを意味すること |
| [Figma Comment property types](https://developers.figma.com/docs/rest-api/comments-property-types/) | ノード相対位置、キャンバス座標、範囲コメント | 位置だけから適用する業務項目を確定できること |
| [Google Sheets Sheet](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/sheets) | GridData、結合、書式、行列属性等 | JSONだけですべての見た目を理解できること |
| [Google Sheets CellData](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/cells) | セルの値、表示情報、note等 | noteとスレッドコメントが同じ情報であること |
| [Google Drive Comments](https://developers.google.com/workspace/drive/api/guides/manage-comments) | コメントと返信、anchorの考え方 | 全ネイティブコメントを確実にセルへ対応付けられること |
| [Google Drive comments.list](https://developers.google.com/workspace/drive/api/reference/rest/v3/comments/list) | fields、ページ送り、削除済み項目の指定 | 削除済み本文が必ず取得できること |
| [SpreadsheetMLの構造](https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/structure-of-a-spreadsheetml-document) | OOXMLのワークブックと部品構造 | 自由配置の意味関係が自動的に分かること |
| [openpyxl Tutorial](https://openpyxl.readthedocs.io/en/3.1/tutorial.html) | 対応要素と保存時の制約、数式キャッシュの扱い | 単一ライブラリで全Excel要素を完全に保持できること |
| [Microsoft Research SpreadsheetLLM](https://www.microsoft.com/en-us/research/publication/encoding-spreadsheets-for-large-language-models/) | 配置・構造を使った表現とスプレッドシート理解の研究 | 自社の設計書やFigmaの意味を正確に復元できること |
| [AWS Reimagine workflow](https://aws.amazon.com/blogs/migration-and-modernization/reimagining-mainframe-applications-with-aws-transform-and-claude-code/) | 依存・データ・ルールの抽出、仕様生成、人の確認、コード・テストへの接続 | すべての言語と資料で無人生成が成功すること |
| [AWS Transform user guide](https://docs.aws.amazon.com/transform/latest/userguide/transform-app-mainframe-workflow.html) | 入口・依存の解析、要求とルールの追跡関係 | 原実装と同じなら業務目的も正しいこと |
| [Thoughtworks Odoo実験](https://www.thoughtworks.com/en-de/insights/blog/generative-ai/blackbox-reverse-engineering-ai-rebuild-application-without-accessing-code) | UI、DB変化、通信による仕様復元、試作による不足発見 | 実験で完全なDB互換性や全機能が実証されたこと |
| [Cucumber Example Mapping](https://cucumber.io/docs/bdd/example-mapping/) | ルール、具体例、質問を分ける実践 | 具体例だけで全入力を網羅できること |
| [Specification by Example](https://martinfowler.com/bliki/SpecificationByExample.html) | 異なる方法による検証、具体例と一般ルールの併用 | 自動テストの合格だけで仕様の妥当性が証明されること |

AIによる仕様化・再実装の公開事例は、提供者による報告や限定実験も含みます。本手順では公開された成果率を自社の見積もりに転用していません。
