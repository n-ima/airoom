import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import toolkit as t

ROOT = Path(__file__).resolve().parents[1]


class ToolkitTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def demo(self):
        out = self.root / 'demo'
        subprocess.run([sys.executable, str(ROOT / 'scripts/create_demo.py'), str(out)], check=True, capture_output=True)
        return out

    def test_empty_gate_fails(self):
        t.init_run(self.root / 'empty')
        self.assertFalse(t.validate(self.root / 'empty', True)['ok'])

    def test_demo_gate_passes(self):
        self.assertTrue(t.validate(self.demo(), True)['ok'])

    def test_unconfirmed_oracle_fails(self):
        out = self.demo()
        claims = t.rows(out / 'claims.jsonl')
        claims[0]['status'] = 'candidate'
        t.write_rows(out / 'claims.jsonl', claims)
        self.assertFalse(t.validate(out)['ok'])

    def test_missing_decision_fails(self):
        out = self.demo()
        t.write_rows(out / 'decisions.jsonl', [])
        self.assertFalse(t.validate(out)['ok'])

    def test_evidence_tamper_fails(self):
        out = self.demo()
        (out / 'synthetic-source.txt').write_text('changed', encoding='utf-8')
        self.assertFalse(t.validate(out)['ok'])

    def test_duplicate_id_fails(self):
        out = self.demo()
        records = t.rows(out / 'claims.jsonl')
        t.write_rows(out / 'claims.jsonl', records * 2)
        self.assertFalse(t.validate(out)['ok'])

    def test_open_discrepancy_fails_gate(self):
        out = self.demo()
        t.write_rows(out / 'discrepancies.jsonl', [{'id':'X-1','status':'open'}])
        self.assertFalse(t.validate(out, True)['ok'])

    def test_correct_adapter(self):
        out = self.demo()
        result = t.run_tests(out / 'tests.jsonl', ROOT / 'examples/adapter_correct.py', self.root / 'result')
        self.assertEqual([r['status'] for r in result], ['passed'] * 3)

    def test_boundary_defect_detected(self):
        out = self.demo()
        result = t.run_tests(out / 'tests.jsonl', ROOT / 'examples/adapter_legacy_bug.py', self.root / 'result')
        self.assertEqual([r['status'] for r in result], ['passed','failed','passed'])

    def test_adapter_gets_no_expected(self):
        out = self.demo()
        adapter = self.root / 'adapter.py'
        adapter.write_text("import json,sys\nr=json.load(sys.stdin)\nassert 'expected' not in r\nprint('{}')\n", encoding='utf-8')
        result = t.run_tests(out / 'tests.jsonl', adapter, self.root / 'result')
        self.assertTrue(all(r['status'] == 'failed' for r in result))

    def test_invalid_adapter_output_blocked(self):
        out = self.demo()
        adapter = self.root / 'adapter.py'
        adapter.write_text("print('not json')\n", encoding='utf-8')
        result = t.run_tests(out / 'tests.jsonl', adapter, self.root / 'result')
        self.assertTrue(all(r['status'] == 'blocked' for r in result))

    def test_draft_never_passes(self):
        out = self.demo()
        cases = t.rows(out / 'tests.jsonl')
        cases[0]['status'] = 'draft'
        t.write_rows(out / 'tests.jsonl', cases)
        result = t.run_tests(out / 'tests.jsonl', ROOT / 'examples/adapter_correct.py', self.root / 'result')
        self.assertEqual(result[0]['status'], 'blocked')

    def test_empty_test_set_errors(self):
        path = self.root / 'empty.jsonl'
        path.write_text('', encoding='utf-8')
        with self.assertRaises(ValueError):
            t.run_tests(path, ROOT / 'examples/adapter_correct.py', self.root / 'out')

    def test_strict_oracle(self):
        self.assertTrue(t.compare({'x':True}, {'x':1}))
        self.assertTrue(t.compare({'x':[]}, {'x':[1]}))
        self.assertEqual(t.compare({'x':True}, {'x':True, 'extra':1}), [])

    def test_fresh_prevents_overwrite(self):
        out = t.fresh(self.root / 'one')
        with self.assertRaises(ValueError):
            t.fresh(out)

    def test_figma_thread_and_anchor(self):
        doc = {'document':{'id':'0:0','type':'DOCUMENT','children':[{'id':'1:1','type':'FRAME','name':'申請'}]}}
        comments = {'comments':[{'id':'b','parent_id':'a','message':'法人のみ','created_at':'2'},
                                {'id':'a','message':'必須','created_at':'1','client_meta':{'node_id':'1:1'}}]}
        result = t.figma_index(doc, comments)
        self.assertEqual(len(result['threads']),1)
        self.assertEqual([c['id'] for c in result['threads'][0]['comments']],['a','b'])
        self.assertEqual(result['threads'][0]['binding'],'explicit_frame_not_confirmed_control')

    def test_figma_missing_parent(self):
        result = t.figma_index({'document':{'id':'0','type':'DOCUMENT'}}, {'comments':[{'id':'b','parent_id':'gone'}]})
        self.assertEqual(result['threads'][0]['binding'],'missing_parent')

    def test_figma_region_is_unresolved(self):
        result = t.figma_index({'document':{'id':'0','type':'DOCUMENT'}}, {'comments':[{'id':'a','client_meta':{'x':1,'y':2,'region_width':3}}]})
        self.assertEqual(result['threads'][0]['binding'],'region_requires_visual_review')

    def workbook(self, malicious=False):
        p = self.root / 'input.xlsx'
        with zipfile.ZipFile(p,'w') as z:
            z.writestr('xl/workbook.xml','<workbook xmlns:r="urn:rel"><sheets><sheet name="仕様" sheetId="1" r:id="rId1" state="hidden"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/worksheets/sheet1.xml','<worksheet><sheetData><row r="1" hidden="1"><c r="A1" t="inlineStr"><is><t>10万円以上</t></is></c><c r="B1"><f>1+1</f><v>2</v></c></row></sheetData><mergeCells><mergeCell ref="A1:A2"/></mergeCells></worksheet>')
            z.writestr('xl/comments/comment1.xml','<comments><comment ref="A1"><text><t>注意</t></text></comment></comments>')
            if malicious:
                z.writestr('../escape.txt','bad')
        return p

    def test_xlsx_structure_and_integrity(self):
        out = self.root / 'out'
        t.extract_xlsx(self.workbook(),out)
        data = t.read(out / 'workbook.json')
        self.assertEqual(data['sheets'][0]['state'],'hidden')
        self.assertEqual(data['sheets'][0]['merges'],['A1:A2'])
        self.assertEqual(data['sheets'][0]['cells'][0]['raw_value'],'10万円以上')
        self.assertEqual(data['sheets'][0]['cells'][1]['formula'],'1+1')
        self.assertEqual(data['comments'][0]['text'],'注意')
        self.assertTrue(t.verify_manifest(out)['ok'])

    def test_zip_traversal_rejected(self):
        with self.assertRaises(ValueError):
            t.extract_xlsx(self.workbook(True), self.root / 'out')
        self.assertFalse((self.root / 'escape.txt').exists())

    def test_manifest_tamper(self):
        out = self.root / 'out'
        t.extract_xlsx(self.workbook(),out)
        (out / 'workbook.json').write_text('{}', encoding='utf-8')
        self.assertFalse(t.verify_manifest(out)['ok'])

    def test_google_comment_pagination_and_replies(self):
        seen = []
        def fake(url, headers, raw=False):
            seen.append(url)
            if '/replies?' in url:
                return {'replies':[{'id':'reply'}]}
            if '/comments?' in url:
                return {'comments':[{'id':'c2'}]} if 'pageToken=next' in url else {'comments':[{'id':'c1'}], 'nextPageToken':'next'}
            if 'sheets.googleapis.com' in url:
                return {'sheets':[]}
            return {'id':'sheet','version':'1','modifiedTime':'x'}
        with patch.dict('os.environ',{'GOOGLE_ACCESS_TOKEN':'test-only'}), patch.object(t,'get',side_effect=fake):
            t.collect_sheets('sheet',self.root / 'out')
        data = t.read(self.root / 'out/comments.json')
        self.assertEqual(len(data['comments']),2)
        self.assertTrue(all(c['replies'] for c in data['comments']))
        self.assertTrue(any('pageToken=next' in x for x in seen))

    def test_google_capture_change_flagged(self):
        counter = 0
        def fake(url, headers, raw=False):
            nonlocal counter
            if '/comments?' in url: return {'comments':[]}
            if 'sheets.googleapis.com' in url: return {'sheets':[]}
            counter += 1
            return {'version':str(counter),'modifiedTime':'x'}
        with patch.dict('os.environ',{'GOOGLE_ACCESS_TOKEN':'test-only'}), patch.object(t,'get',side_effect=fake):
            t.collect_sheets('sheet',self.root / 'out')
        self.assertEqual(t.read(self.root / 'out/manifest.json')['status'],'changed_during_capture')

    def test_review_escapes_untrusted_text(self):
        out = self.demo()
        es = t.rows(out / 'evidence.jsonl'); es[0]['excerpt'] = '<script>alert(1)</script>'
        t.write_rows(out / 'evidence.jsonl', es)
        t.review(out,self.root / 'review.html')
        self.assertNotIn('<script>',(self.root / 'review.html').read_text(encoding='utf-8'))

    def test_inventory_exclusion_visible(self):
        src = self.root / 'src'; src.mkdir()
        (src / 'app.py').write_text('print(1)',encoding='utf-8')
        (src / '.env').write_text('SECRET=x',encoding='utf-8')
        t.inventory(src,self.root / 'inventory')
        self.assertEqual(len(t.rows(self.root / 'inventory/files.jsonl')),1)
        self.assertEqual(t.read(self.root / 'inventory/exclusions.json')[0]['path'],'.env')


if __name__ == '__main__':
    unittest.main()
