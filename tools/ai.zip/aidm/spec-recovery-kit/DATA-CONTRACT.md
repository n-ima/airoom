# 台帳のデータ形式

各JSONLファイルは、一行に一つのJSONオブジェクトを置きます。下記の見やすい複数行JSONは説明用です。実ファイルへの保存時は一行へ直すか、Pythonのwrite_rowsを使用します。UTF-8で保存します。IDは機能内で安定させます。同梱validateが行う機械検査と、AI・人による意味の検査を混同しないでください。

## scope.json

```json
{
  "feature_id": "F-ORDER-CANCEL",
  "baseline": "source commitと資料版と稼働版を実際の値で記入",
  "owner": "実際の業務判断者",
  "in_scope": ["注文取消と在庫への影響"],
  "out_of_scope": ["返品後の返金"],
  "unresolved": ["本番と検証環境の設定差が未確認"]
}
```

unresolvedは根拠を確認してから減らします。gateを通すために空にしません。

## evidence.jsonl

```json
{
  "id": "E-XLS-001",
  "kind": "document",
  "source": "取得済みファイルの絶対パスまたはrunからの相対パス",
  "locator": "注文シート B12:F15 と関連注記 N3",
  "snapshot": "実際の資料版または取得run ID",
  "excerpt": "実際に確認した短い原文抜粋",
  "sha256": "根拠ファイル全体のSHA256を64桁の小文字16進数で記入"
}
```

根拠IDは一つの意味を裏付ける位置に付けます。同じファイルでも、別の位置を別IDで参照できます。画像なら画像全体のハッシュと対象領域、JSONなら取得JSONのハッシュとノード/スレッドID、ソースならファイルのハッシュと行・シンボル・コミットを記録します。excerptが根拠に本当に含まれるかはレビューで検査します。ローカルファイルの存在とハッシュはvalidateが確認します。

次のコマンドはハッシュを計算して追記します。IDの重複は拒否します。

```powershell
python toolkit.py evidence work/order-cancel-001 captures/excel-order-001/workbook.json --id E-XLS-001 --kind document --locator "注文 B12:F15" --excerpt "原資料で確認した文章" --snapshot excel-order-001
```

kindはdocument、figma_comment、implementation、observation、decisionなどを使います。現行validateはkindの空欄は拒否しますが、語彙全体は制限していません。sourceがHTTP(S)の場合はローカルハッシュ照合ができません。基準版確定前には、アクセス可能なスナップショットを取得してローカルファイルへ関連付けます。

## claims.jsonl

```json
{
  "id": "BR-CANCEL-001",
  "feature_id": "F-ORDER-CANCEL",
  "origin": "document",
  "statement": "出荷確定済みの注文は取消できない",
  "precondition": "注文が出荷確定済みの状態で取消要求を受ける",
  "outcome": "取消を拒否し、注文と在庫は変更しない",
  "rationale_status": "hypothesis",
  "rationale": "出荷と取消の不整合を防ぐためという仮説。原資料には理由の明記なし",
  "evidence_ids": ["E-XLS-001"],
  "status": "candidate",
  "open_questions": ["出荷確定の取消後は注文取消できるか"]
}
```

originはdocument、implementation、observation、decision。statusはcandidate、confirmed、retired、blocked。rationale_statusはdocumented、hypothesis、unknownです。confirmedにはdecision_idと、そのclaimを対象にしたdecisionsの記録が必要です。

資料側と実装側の同じルールは、初回は別IDで記録します。採用仕様をconfirmedにするとき、重複や廃止する候補はretiredとし、理由と後継IDを追加フィールドで残します。必要性がunknownでも事実として動作を確認できる場合はあります。今後採用する理由が未確認の重要ルールは、人の工程完了判定では保留にします。

## decisions.jsonl

```json
{
  "id": "D-CANCEL-001",
  "claim_ids": ["BR-CANCEL-001"],
  "decided_by": "実際に回答した担当者",
  "decided_at": "実際の判断日時をISO形式で記入",
  "authority_basis": "業務責任者としての役割と確認記録への参照",
  "reason": "採用理由を実際の回答から記載",
  "selected_behavior": "どの条件で何をするかという決定内容",
  "evidence_ids": ["E-MEETING-001"]
}
```

実際の回答をまだ受けていなければこの記録を作らず、questions.mdへ質問案を保存します。validateは主要項目の有無と参照を検査するだけで、人物の権限や回答の真正性は検証しません。

## coverage.jsonl

```json
{"id":"CV-001","evidence_id":"E-XLS-001","disposition":"mapped","claim_ids":["BR-CANCEL-001"]}
```

```json
{"id":"CV-002","evidence_id":"E-FIG-OLD-001","disposition":"excluded","reason":"旧案と確認。D-002参照"}
```

```json
{"id":"CV-003","evidence_id":"E-NOTE-001","disposition":"unresolved","reason":"注記の対象が二つの画面にまたがるため未確定"}
```

dispositionはmapped、excluded、unresolved。mappedにはclaim_ids、それ以外にはreasonが必要です。すべての資料領域・スレッド・業務上意味のある実装条件を母集団として登録してください。登録していないものはgateで検知できません。100%の対応率と、原資料の完全な理解は別です。

## discrepancies.jsonl

```json
{
  "id": "X-001",
  "claim_ids": ["BR-DOC-001", "BR-CODE-001"],
  "difference": "資料は以上、実装は超という境界の違い",
  "impact": "境界値ちょうどで承認の有無が変わる",
  "next_investigation": "変更記録と境界値の実行観測を確認する",
  "status": "open"
}
```

statusはopen、resolved、accepted_difference。open以外にはdecision_idが必要です。accepted_differenceは、将来仕様や既知の互換性差を理由付きで採用した場合です。テストが失敗してもよいという一括免除には使いません。現行との比較用結果と、今後の実装に要求する期待値を区別します。

## tests.jsonl

```json
{
  "id": "T-CANCEL-001",
  "claim_ids": ["BR-CANCEL-001"],
  "status": "draft",
  "input": {
    "initial_state": "shipment_confirmed",
    "action": "cancel_order",
    "actor": "authorized_operator"
  },
  "expected": {
    "accepted": false,
    "final_state": "shipment_confirmed",
    "inventory_changes": [],
    "notifications": []
  },
  "oracle_basis": "BR-CANCEL-001と判断記録に基づく。現行出力のコピーではない"
}
```

承認後にstatus=approvedとapproved_byを設定します。テストに紐づくclaimもconfirmedである必要があります。入力と期待結果のフィールドは対象システムごとに設計し、observation-contract.mdへ意味を定義します。

toolkit.py testは、各ケースのidとinputだけをアダプターへ渡します。expectedは渡しません。オブジェクトは期待するキーの部分一致、配列とスカラーは型も含む完全一致です。例えばtrueと1は区別します。不要な可変時刻や生成IDは観測契約で正規化し、業務上意味のある差を消さないようレビューします。

副作用なしを検証する場合、空配列などの期待を記載するだけでは不十分です。アダプターが実際のDB・イベント・通知を調べ、その観測から値を作る必要があります。

## AI作業用の補助ファイル

| ファイル | 必須内容 |
|---|---|
| regions.json | 領域ID、原資料版、範囲、画像、親見出し、関連注記、未解決事項 |
| figma-bindings.json | スレッドID、発言ID、対象候補、対応根拠、議論状態、未解決事項 |
| reading-profile.md | 書式群、見出し、注記の読み方、色の確認済み意味、正解例と誤読例 |
| state.md | 機能ID、工程、入力版、完了範囲、次の作業、回答待ち |
| environment.md | 稼働版、設定、権限、DB版、初期データ、時刻・非同期の扱い |
| validation-report.md | 工程別結果、未検証事項、承認者、対象外、テストと再実装の結果 |

補助ファイルの意味・画像・参照の完全性は現行validateの検査対象外です。工程ごとのプロンプトとCHECKLISTで確認します。
