"""Intentional off-by-one defect for the offline demonstration."""
import json
import sys

request = json.load(sys.stdin)
amount = request["input"]["amount_yen"]
print(json.dumps({"approval_required": amount > 100000, "writes": []}))
