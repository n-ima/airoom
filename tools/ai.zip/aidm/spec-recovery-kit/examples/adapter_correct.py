"""Example only: standalone toy implementation, not the user's application."""
import json
import sys

request = json.load(sys.stdin)
amount = request["input"]["amount_yen"]
if type(amount) is not int or amount < 0:
    raise ValueError("Fixture supports nonnegative integer JPY only")
print(json.dumps({"approval_required": amount >= 100000, "writes": []}))
