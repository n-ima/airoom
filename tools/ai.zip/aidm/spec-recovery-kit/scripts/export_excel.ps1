param(
    [Parameter(Mandatory=$true)][string]$Workbook,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
# Native Excel display export. Use only a trusted workbook copy. Never save the source.
$ErrorActionPreference = 'Stop'
$sourcePath = (Resolve-Path -LiteralPath $Workbook).Path
$destination = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $destination) { throw 'Use a new output directory.' }
New-Item -ItemType Directory -Path $destination | Out-Null
$excel = $null
$book = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    $excel.AutomationSecurity = 3 # msoAutomationSecurityForceDisable
    $book = $excel.Workbooks.Open($sourcePath, 0, $true) # UpdateLinks=0, ReadOnly=true
    $book.ExportAsFixedFormat(0, (Join-Path $destination 'original-print-layout.pdf'))
    $records = @()
    for ($i = 1; $i -le $book.Worksheets.Count; $i++) {
        $sheet = $book.Worksheets.Item($i)
        $records += [pscustomobject]@{
            index=$i; name=$sheet.Name; visible=$sheet.Visible;
            usedRange=$sheet.UsedRange.Address(); originalPrintArea=$sheet.PageSetup.PrintArea
        }
        # Supplement covers hidden sheets/cells and ignores stale print areas.
        # It is NOT a replacement for the original appearance. Changes are in memory only.
        $sheet.Visible = -1
        $sheet.UsedRange.EntireRow.Hidden = $false
        $sheet.UsedRange.EntireColumn.Hidden = $false
        $sheet.ExportAsFixedFormat(0, (Join-Path $destination ('sheet-{0:D3}-supplement.pdf' -f $i)), 0, $true, $true)
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($sheet)
    }
    $records | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $destination 'sheet-map.json') -Encoding UTF8
    'PDF is a display aid. Check clipping, off-sheet drawings, comment threads, fonts, and pagination. Cached formulas can differ after Excel opens the workbook.' | Set-Content -LiteralPath (Join-Path $destination 'LIMITATIONS.txt') -Encoding UTF8
}
finally {
    if ($book) { $book.Close($false); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($book) }
    if ($excel) { $excel.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel) }
}
