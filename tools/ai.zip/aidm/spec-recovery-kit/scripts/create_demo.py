"""Generate a synthetic, labeled example. Does not touch real project evidence."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from toolkit import init_run, dump, write_rows, digest

if len(sys.argv) != 2:
    raise SystemExit('Usage: python scripts/create_demo.py NEW_OUTPUT_DIRECTORY')
out = Path(sys.argv[1]).resolve()
init_run(out)
raw = out / 'synthetic-source.txt'
raw.write_text('架空の規程：申請金額が100000円以上の場合は上長承認を必須とする。事前判定ではデータを更新しない。\n', encoding='utf-8')
dump(out / 'scope.json', {'feature_id':'F-DEMO', 'baseline':'synthetic-v1', 'owner':'DEMO ONLY', 'in_scope':['承認要否の事前判定'], 'out_of_scope':['承認実行'], 'unresolved':[]})
write_rows(out / 'evidence.jsonl', [{'id':'E-001','kind':'document','source':'synthetic-source.txt','locator':'line 1','snapshot':'synthetic-v1','excerpt':raw.read_text(encoding='utf-8').strip(),'sha256':digest(raw.read_bytes())}])
write_rows(out / 'claims.jsonl', [{'id':'BR-001','feature_id':'F-DEMO','origin':'document','statement':'10万円以上は上長承認が必要','precondition':'非負整数の日本円金額を事前判定する','outcome':'100000円以上なら承認必須。事前判定では書き込みなし','rationale_status':'documented','rationale':'架空の承認規程に従う','evidence_ids':['E-001'],'status':'confirmed','decision_id':'D-001'}])
write_rows(out / 'decisions.jsonl', [{'id':'D-001','claim_ids':['BR-001'],'decided_by':'架空の業務責任者','decided_at':'2026-10-05','authority_basis':'デモ用の架空権限。実承認として使用禁止','reason':'架空規程に合わせる','selected_behavior':'amount >= 100000; no writes'}])
write_rows(out / 'coverage.jsonl', [{'id':'CV-001','evidence_id':'E-001','disposition':'mapped','claim_ids':['BR-001']}])
write_rows(out / 'tests.jsonl', [{'id':f'T-{i:03}','claim_ids':['BR-001'],'status':'approved','approved_by':'DEMO ONLY','input':{'amount_yen':amount},'expected':{'approval_required':expected,'writes':[]},'oracle_basis':'D-001と架空規程の境界値。現行出力から期待値を取得していない'} for i,(amount,expected) in enumerate([(99999,False),(100000,True),(100001,True)],1)])
print(str(out))
