// Optional publishing utility. Runtime toolkit itself uses only Python standard library.
const fs = require('node:fs');
const path = require('node:path');
const { marked } = require(process.argv[2] || 'marked');
const root = path.resolve(__dirname, '..');
const esc = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const box = (x,y,w,title,sub,fill='#edf3f8') => `<g><rect x="${x}" y="${y}" width="${w}" height="76" rx="10" fill="${fill}" stroke="#9aafbd"/><text x="${x+w/2}" y="${y+30}" text-anchor="middle" font-size="19" font-weight="600">${esc(title)}</text><text x="${x+w/2}" y="${y+55}" text-anchor="middle" font-size="14">${esc(sub)}</text></g>`;
const arrow = d => `<path d="${d}" fill="none" stroke="#42677d" stroke-width="2" marker-end="url(#arrow)"/>`;
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1015" role="img" aria-labelledby="title desc"><title id="title">業務設計書復元の全体フロー</title><desc id="desc">資料の読解と実装調査を別々に進め、不一致の判断後に設計書とテストを作成する。検証で不足があれば調査へ戻る。</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8" fill="#42677d"/></marker></defs><g font-family="Segoe UI,Yu Gothic,sans-serif" fill="#153b57">
${box(290,15,420,'対象業務と基準版を決定','資料版・ソース版・設定・稼働環境')}
${arrow('M500 91 V112 H165 V135')}${arrow('M500 112 V135')}${arrow('M500 112 H835 V135')}
${box(15,140,300,'Excel と Sheets','セル構造 ＋ 表示画像 ＋ コメント')}
${box(350,140,300,'Figma','ノード ＋ 周辺画像 ＋ スレッド')}
${box(685,140,300,'既存実装','入口 ＋ SQL ＋ 設定 ＋ 後続処理')}
${arrow('M165 216 V235 H325 V255')}${arrow('M500 216 V235 H325')}${arrow('M835 216 V255')}
${box(65,260,520,'配置と注記の関係を復元し読解を検査','資料が述べる仕様候補と根拠を保存')}
${box(685,260,300,'現行動作を独立に抽出','実装事実と未解決依存を保存')}
${arrow('M325 336 V358 H500 V380')}${arrow('M835 336 V358 H500')}
${box(250,385,500,'条件と結果を照合し不一致を調査','版・変更理由・境界値の動作観測')}
${arrow('M500 461 V495')}
${box(250,500,500,'必要性と採用する動作を判断','事実・選択肢・影響を確認し判断記録へ','#fff4df')}
${arrow('M500 576 V610')}
${box(250,615,500,'業務設計書を生成し根拠へ戻って確認','目的・ルール・状態・例外・受入条件')}
${arrow('M500 691 V725')}
${box(250,730,500,'設計書からテストを作り実行','期待値を固定し実装の観測結果と比較')}
${arrow('M500 806 V840')}
${box(250,845,500,'小さな再実装で仕様の十分性を検証','暗黙の判断を解消して基準版として運用','#e7f3ec')}
${arrow('M750 882 H950 V423 H755')}
<text x="800" y="664" font-size="15">不足や不一致は</text><text x="800" y="688" font-size="15">根拠と判断へ戻す</text>
<text x="500" y="975" text-anchor="middle" font-size="15">取得成功・文章の整形・テスト合格だけでは、業務仕様の正しさを確定しない</text>
</g></svg>`;
fs.writeFileSync(path.join(root,'workflow.svg'), svg, 'utf8');
const docs = [
  ['GUIDE.md','実行手順'],['PROMPTS.md','工程別プロンプト'],['DATA-CONTRACT.md','台帳の形式'],
  ['IMPLEMENTATION-RECIPES.md','実装調査と接続例'],['CHECKLIST.md','完了判定'],['SOURCES.md','出典'],['README.md','実行環境とコマンド']
];
const sections = docs.map(([file,label],i) => {
  let source = fs.readFileSync(path.join(root,file),'utf8').replace(/```mermaid[\s\S]*?```/g, `<figure class="flow">${svg}<figcaption>原文のMermaid図もGUIDE.mdに保存しています。</figcaption></figure>`);
  let rendered = marked.parse(source);
  let counter = 0;
  rendered = rendered.replace(/<h([1-3])>([\s\S]*?)<\/h\1>/g, (_,level,text)=>`<h${level} id="s${i}-h${counter++}">${text}</h${level}>`);
  for(const [target,,] of docs) rendered = rendered.replaceAll(`href="${target}"`, `href="#chapter-${docs.findIndex(x=>x[0]===target)}"`);
  return `<section class="chapter" id="chapter-${i}"><div class="chapter-label">${String(i+1).padStart(2,'0')} / ${esc(label)}</div>${rendered}</section>`;
}).join('\n');
const nav = docs.map(([,label],i)=>`<a href="#chapter-${i}">${esc(label)}</a>`).join('');
const output = `<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>業務設計書復元 実行ハンドブック</title><style>
:root{color-scheme:light;--ink:#182d3d;--muted:#526777;--line:#d9e2e9;--blue:#174968}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:22px}body{margin:0;background:#edf2f6;color:var(--ink);font:16px/1.85 'Segoe UI','Yu Gothic',Meiryo,sans-serif}header{background:#13364c;color:white;padding:50px max(24px,calc((100vw - 1100px)/2)) 40px}header p{color:#dce9f0;max-width:850px}header .eyebrow{font-size:13px;letter-spacing:.1em}header h1{font-size:30px;line-height:1.5;margin:12px 0}nav{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}nav a{border:1px solid #668499;border-radius:6px;padding:6px 12px;color:white;text-decoration:none;font-size:14px}main{max-width:1160px;margin:28px auto;padding:0 24px}section.chapter{background:white;padding:40px 48px;margin-bottom:30px;border:1px solid var(--line);border-radius:10px}.chapter-label{color:#547283;font-size:13px;font-weight:600;letter-spacing:.08em}.chapter h1{font-size:28px;line-height:1.55}.chapter h2{font-size:23px;border-bottom:2px solid #e4edf3;padding-bottom:12px;margin-top:48px;line-height:1.6}.chapter h3{font-size:19px;margin-top:30px}a{color:#126697}p{margin:16px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#122b3c;color:#edf5fa;padding:22px;border-radius:7px;font:13px/1.8 Consolas,monospace}code{font-family:Consolas,monospace}p code,li code{background:#eef4f8;padding:2px 4px}table{border-collapse:collapse;width:100%;font-size:14px;margin:24px 0;table-layout:fixed;overflow-wrap:anywhere}th,td{border:1px solid var(--line);padding:12px;vertical-align:top}th{background:#eaf2f7;text-align:left}tr:nth-child(even) td{background:#fafcfe}li{margin:7px 0}.flow{margin:25px 0}.flow svg{width:100%;height:auto}figcaption{font-size:12px;color:var(--muted);text-align:center}footer{padding:10px 24px 40px;text-align:center;color:var(--muted);font-size:13px}@media(max-width:700px){header{padding:28px 20px}header h1{font-size:24px}main{padding:0 10px}section.chapter{padding:25px 18px}.chapter h1{font-size:24px}.chapter h2{font-size:21px}table{font-size:12px}th,td{padding:8px}pre{padding:14px;font-size:12px}}@media print{body{background:white;font-size:10pt}header{background:white;color:#123;padding:0}header p{color:#345}nav{display:none}main{margin:0;padding:0;max-width:none}section.chapter{border:0;padding:0;break-before:page}section.chapter:first-child{break-before:auto}pre{color:#123;background:#f2f5f7;font-size:8pt;break-inside:avoid}table{font-size:8pt}tr{break-inside:avoid}.flow{max-width:600px;margin:auto}a{color:#123}footer{display:none}}
</style></head><body><header><div class="eyebrow">2026年10月5日 / 実行手順と検証コード</div><h1>業務設計書復元 実行ハンドブック</h1><p>自由形式のExcelとFigma、既存実装を照合し、AI開発の基準となる設計書と受入テストを作成する。工程ごとの入力、作業、プロンプト、コード、完了条件を収録。</p><nav>${nav}</nav></header><main>${sections}</main><footer>同梱コードは合成データによるオフライン検証済み。実資料・実API・対象システムは導入時に検証。</footer></body></html>`;
fs.writeFileSync(path.join(root,'handbook.html'),output,'utf8');
console.log(JSON.stringify({file:path.join(root,'handbook.html'),bytes:Buffer.byteLength(output),chapters:docs.length}));
