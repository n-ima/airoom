"""Run offline checks and retain the executed commands and expected failures."""
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
base = root / 'work' / ('delivery-' + stamp)
commands = [
    (['-m','unittest','discover','-s','tests','-v'],0),
    (['scripts/create_demo.py',str(base)],0),
    (['toolkit.py','validate',str(base),'--gate'],0),
    (['toolkit.py','test',str(base / 'tests.jsonl'),'examples/adapter_legacy_bug.py',str(base)+'-legacy'],1),
    (['toolkit.py','test',str(base / 'tests.jsonl'),'examples/adapter_correct.py',str(base)+'-correct'],0),
    (['toolkit.py','review',str(base),str(base)+'-review.html'],0),
]
log = ['Offline verification ' + stamp, 'Python ' + sys.version, '']
ok = True
for args, expected in commands:
    result = subprocess.run([sys.executable,*args],cwd=root,capture_output=True,text=True,encoding='utf-8',
                            env={**__import__('os').environ,'PYTHONIOENCODING':'utf-8'})
    log.extend(['COMMAND: python ' + ' '.join(args), f'EXPECTED EXIT: {expected}; ACTUAL: {result.returncode}',
                result.stdout,result.stderr])
    ok = ok and result.returncode == expected
log.append('RESULT: ' + ('PASS' if ok else 'FAIL'))
log.append('NOT TESTED: authenticated APIs, native Excel rendering, user materials, target-system adapters')
(root / 'delivery-validation.txt').write_text('\n'.join(log),encoding='utf-8')
print(json.dumps({'ok':ok,'log':str(root / 'delivery-validation.txt'),'demo':str(base)},ensure_ascii=False))
raise SystemExit(0 if ok else 1)
