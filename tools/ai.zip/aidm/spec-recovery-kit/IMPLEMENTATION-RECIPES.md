# 実装調査とテスト接続の作業例

対象システムの言語・構造は未提示のため、以下は使う箇所を選ぶ作業例です。調査は読み取りから始め、見つからないことを存在しないことと同一視しません。GUIDEのP05とP11に合わせて使います。

## 入口を検索する

ソースのルートで、まずファイル種別と実行設定を確認します。rgがない場合はIDEの参照検索を使えます。

```powershell
rg --files -g '!node_modules' -g '!vendor' -g '!dist' -g '!build'
rg -n '取消|キャンセル|cancel|Cancel' -g '*.*' -g '!package-lock.json' -g '!yarn.lock'
rg -n 'RequestMapping|PostMapping|HttpPost|app\.post|router\.post' -g '*.java' -g '*.cs' -g '*.js' -g '*.ts'
rg -n 'Scheduled|cron|schedule|consumer|subscribe' -g '*.java' -g '*.cs' -g '*.py' -g '*.yml' -g '*.yaml' -g '*.ts'
rg --files -g '*.sql' -g '*.xml' -g '*migration*' -g '*Mapper*'
```

これらは入口候補の探索です。候補から参照検索・定義ジャンプで実際の経路を確認します。正規表現の一致だけで動作経路を確定しません。設定が環境依存なら、対象環境の有効値を別途取得します。

## 状態や判定値を逆向きに調べる

例えば実装中でstatus='SHIPPED'を見つけた場合、比較条件だけでなく更新元も調べます。

```powershell
rg -n 'SHIPPED|shipment_confirmed|出荷確定' -g '*.java' -g '*.cs' -g '*.ts' -g '*.py' -g '*.sql'
rg -n 'UPDATE.*orders|INSERT.*orders|CREATE.*TRIGGER' -g '*.sql'
```

SQLが複数行ならIDE検索やrgの複数行検索へ切り替えます。ORM経由の更新、動的SQL、外部バッチはこの検索だけで網羅できません。データ辞書、ジョブ定義、DBオブジェクト一覧も対象にします。

## 変更理由を探す

```powershell
git rev-parse HEAD
git log --oneline -- path/to/target-file
git log -G '100000|approval|承認' -- path/to/target-file
git blame -L 120,160 -- path/to/target-file
git show COMMIT_ID -- path/to/target-file
```

パス、行番号、COMMIT_IDは実際に確認したものへ置き換えます。コミットメッセージ中のチケット番号から、アクセス可能なチケットを読みます。コメントやコミットは当時の説明であり、その後も正しいとは限りません。

## HTTPで観測するアダプターの最小形

次の例は接続方法の骨格です。そのまま本案件のテストには使えません。APIのパス、認証、初期化、観測項目、副作用の検証をP11で具体化してください。

```python
import json
import os
import sys
import urllib.request

request = json.load(sys.stdin)
base = os.environ['SPEC_TEST_BASE_URL']  # 隔離された検証環境
payload = json.dumps(request['input']).encode('utf-8')
req = urllib.request.Request(
    base + '/replace-with-real-endpoint',
    data=payload,
    headers={'Content-Type':'application/json'},
    method='POST',
)
with urllib.request.urlopen(req, timeout=20) as response:
    body = json.load(response)

# 期待値ではなく、実際の応答から必要な項目を取り出す。
# DB更新や通知は別の読み取り手段で観測し、必要ならこの結果へ追加する。
print(json.dumps({'actual_response':body}, ensure_ascii=False))
```

業務上の拒否をHTTPエラーコードで返すAPIでは、HTTPErrorを捕捉して状態とエラー本文を観測結果へ変換します。タイムアウトや接続不能は業務上の拒否と区別して非ゼロ終了にします。テスト前に初期状態を作り、処理後のDBと外部イベントを対象に応じて読み取ります。

GUI、バッチ、メッセージ駆動でも契約は同じです。stdinで初期状態・操作列を受け、実処理へ接続し、stdoutへ観測結果だけを返します。入力を受け取っただけで期待される値を返すコードは、テスト接続になっていません。

## 差分再調査

新旧の取得manifestとソース差分を比較し、変更された根拠を参照するclaim、共通ルール、テストを列挙します。差分がないファイルでも、依存する設定や共通処理が変われば再評価します。初期キットには意味上の変更影響を完全に計算するコードはないため、台帳の参照とP05/P06で判断します。
